/**
 * Task Manager - Refactored with TypeScript types
 */

// ============================================================
// TYPES AND INTERFACES
// ============================================================

/** Priority as numeric value (1=high, 2=medium, 3=low) - kept for backward compatibility */
export type PriorityNumber = 1 | 2 | 3;

/** Task operations supported by taskOperation() */
export type TaskOperationType =
  | 'add'
  | 'del'
  | 'delete'
  | 'rm'
  | 'remove'
  | 'done'
  | 'complete'
  | 'finish'
  | 'upd'
  | 'update'
  | 'edit'
  | 'list'
  | 'all'
  | 'get'
  | 'find'
  | 'getById'
  | 'byId'
  | 'stats'
  | 'info'
  | 'clear'
  | 'reset';

/** Task object interface */
export interface Task {
  id: number;
  t: string; // title (abbreviated property name for legacy compatibility)
  done: boolean;
  p: PriorityNumber; // priority (abbreviated property name for legacy compatibility)
  created: Date;
  tags: string[];
  completedAt?: Date;
}

/** Filter options for list operation */
export interface ListFilterOptions {
  done?: boolean;
  priority?: PriorityNumber;
  tag?: string;
  sort?: 'priority' | 'created' | 'title';
}

/** Update options for update operation */
export interface UpdateOptions {
  title?: string;
  priority?: number;
  tags?: string[];
}

/** Stats returned by stats operation */
export interface TaskStats {
  total: number;
  completed: number;
  pending: number;
  byPriority: {
    high: number;
    medium: number;
    low: number;
  };
  operations: {
    add: number;
    del: number;
    upd: number;
  };
}

/** Operation stats tracker */
interface OperationStats {
  add: number;
  del: number;
  upd: number;
}

// ============================================================
// DATABASE (in-memory)
// ============================================================

let db: Task[] = [];
let idCounter = 1;
let lastOp = '';
let stats: OperationStats = { add: 0, del: 0, upd: 0 };

// ============================================================
// OPERAZIONI ESTRATTE
// ============================================================

/**
 * Add a new task to the database.
 * @param title - task title
 * @param priority - task priority (1=high, 2=medium, 3=low)
 * @param tags - task tags
 */
function addTask(title: unknown, priority?: unknown, tags?: unknown): Task | null {
  if (!title || typeof title !== 'string') {
    console.log('error: bad title');
    return null;
  }
  if (title.length < 1) {
    console.log('error: empty title');
    return null;
  }
  if (title.length > 100) {
    console.log('error: title too long');
    return null;
  }

  // Check for duplicates (inline, should be extracted)
  for (let i = 0; i < db.length; i++) {
    if (db[i].t === title && db[i].done === false) {
      console.log('error: duplicate task');
      return null;
    }
  }

  // Validate and normalize priority
  let normalizedPriority: PriorityNumber = 2; // default to medium
  if (typeof priority === 'number' && priority >= 1 && priority <= 3) {
    normalizedPriority = priority as PriorityNumber;
  }

  // Normalize tags
  const normalizedTags: string[] = Array.isArray(tags) ? tags : [];

  // Create task object
  const task: Task = {
    id: idCounter++,
    t: title,
    done: false,
    p: normalizedPriority,
    created: new Date(),
    tags: normalizedTags,
  };

  db.push(task);
  stats.add++;

  // Log (side effect)
  console.log(`Added task: ${task.t}`);

  return task;
}

/**
 * Delete a task from the database.
 * @param id - task id to delete
 */
function deleteTask(id: number | null | undefined): boolean {
  if (!id) {
    console.log('error: no id');
    return false;
  }

  let found = false;
  let idx = -1;
  for (let i = 0; i < db.length; i++) {
    if (db[i].id === id) {
      found = true;
      idx = i;
      break;
    }
  }

  if (!found) {
    console.log('error: task not found');
    return false;
  }

  const removed = db.splice(idx, 1)[0];
  stats.del++;
  console.log(`Deleted task: ${removed.t}`);
  return true;
}

/**
 * Mark a task as completed.
 * @param id - task id to complete
 */
function completeTask(id: number | null | undefined): boolean {
  if (!id) {
    console.log('error: no id');
    return false;
  }

  for (let i = 0; i < db.length; i++) {
    if (db[i].id === id) {
      if (db[i].done) {
        console.log('error: already done');
        return false;
      }
      db[i].done = true;
      db[i].completedAt = new Date();
      stats.upd++;
      console.log(`Completed task: ${db[i].t}`);
      return true;
    }
  }
  console.log('error: task not found');
  return false;
}

/**
 * Update a task's properties.
 * @param id - task id to update
 * @param options - update options (title, priority, tags)
 */
function updateTask(id: number | null | undefined, options: UpdateOptions | null | undefined): Task | false {
  if (!id) {
    console.log('error: no id');
    return false;
  }

  for (let i = 0; i < db.length; i++) {
    if (db[i].id === id) {
      // Update title if provided
      if (options && options.title) {
        if (typeof options.title === 'string' && options.title.length > 0 && options.title.length <= 100) {
          db[i].t = options.title;
        }
      }
      // Update priority if provided
      if (options && options.priority !== undefined) {
        if (typeof options.priority === 'number' && options.priority >= 1 && options.priority <= 3) {
          db[i].p = options.priority as PriorityNumber;
        }
      }
      // Update tags if provided
      if (options && options.tags) {
        if (Array.isArray(options.tags)) {
          db[i].tags = options.tags;
        }
      }
      stats.upd++;
      console.log(`Updated task: ${db[i].t}`);
      return db[i];
    }
  }
  console.log('error: task not found');
  return false;
}

/**
 * List tasks with optional filtering and sorting.
 * @param filterOptions - filter and sort options
 */
function listTasks(filterOptions?: ListFilterOptions | null): Task[] {
  if (!filterOptions) {
    return [...db];
  }

  let result = [...db];

  // Filter by done status
  if (filterOptions.done !== undefined) {
    result = result.filter((t: Task) => t.done === filterOptions.done);
  }

  // Filter by priority
  if (filterOptions.priority !== undefined) {
    result = result.filter((t: Task) => t.p === filterOptions.priority);
  }

  // Filter by tag
  if (filterOptions.tag) {
    result = result.filter((t: Task) => t.tags && t.tags.includes(filterOptions.tag!));
  }

  // Sort options
  if (filterOptions.sort) {
    if (filterOptions.sort === 'priority') {
      result.sort((a: Task, b: Task) => a.p - b.p);
    } else if (filterOptions.sort === 'created') {
      result.sort((a: Task, b: Task) => a.created.getTime() - b.created.getTime());
    } else if (filterOptions.sort === 'title') {
      result.sort((a: Task, b: Task) => a.t.localeCompare(b.t));
    }
  }

  return result;
}

/**
 * Find a task by its id.
 * @param id - task id to find
 */
function findTask(id: number | null | undefined): Task | null {
  if (!id) {
    return null;
  }
  for (let i = 0; i < db.length; i++) {
    if (db[i].id === id) {
      return db[i];
    }
  }
  return null;
}

/**
 * Get statistics about tasks.
 */
function getStats(): TaskStats {
  return {
    total: db.length,
    completed: db.filter((t: Task) => t.done).length,
    pending: db.filter((t: Task) => !t.done).length,
    byPriority: {
      high: db.filter((t: Task) => t.p === 1).length,
      medium: db.filter((t: Task) => t.p === 2).length,
      low: db.filter((t: Task) => t.p === 3).length,
    },
    operations: { ...stats },
  };
}

/**
 * Clear/reset the database.
 */
function clearDatabase(): boolean {
  db = [];
  idCounter = 1;
  stats = { add: 0, del: 0, upd: 0 };
  console.log('Database cleared');
  return true;
}

// ============================================================
// FUNZIONE PRINCIPALE: taskOperation() - Rinominata da x()
// ============================================================

/** Return type for taskOperation - varies based on operation */
export type TaskOperationResult = Task | Task[] | TaskStats | boolean | null;

/**
 * Main task operation function (dispatcher).
 * @param data - task title for add, or null for other operations
 * @param operation - operation type
 * @param id - task id or filter options (for list operations)
 * @param options - additional data (optional)
 */
export function taskOperation(
  data: unknown,
  operation: string,
  id?: number | ListFilterOptions | null,
  options?: UpdateOptions | string[] | null
): TaskOperationResult {
  // Track operation
  lastOp = operation;

  // OPERATION: add
  if (operation === 'add') {
    return addTask(data, id, options);
  }

  // OPERATION: delete
  if (operation === 'del' || operation === 'delete' || operation === 'rm' || operation === 'remove') {
    return deleteTask(id as number | null | undefined);
  }

  // OPERATION: complete/done
  if (operation === 'done' || operation === 'complete' || operation === 'finish') {
    return completeTask(id as number | null | undefined);
  }

  // OPERATION: update
  if (operation === 'upd' || operation === 'update' || operation === 'edit') {
    return updateTask(id as number | null | undefined, options as UpdateOptions | null | undefined);
  }

  // OPERATION: list/get all
  if (operation === 'list' || operation === 'all' || operation === 'get') {
    return listTasks(id as ListFilterOptions | null | undefined);
  }

  // OPERATION: find by id
  if (operation === 'find' || operation === 'getById' || operation === 'byId') {
    return findTask(id as number | null | undefined);
  }

  // OPERATION: stats
  if (operation === 'stats' || operation === 'info') {
    return getStats();
  }

  // OPERATION: clear/reset
  if (operation === 'clear' || operation === 'reset') {
    return clearDatabase();
  }

  // Unknown operation
  console.log(`error: unknown operation '${operation}'`);
  return null;
}

// Alias per retrocompatibilità
export const x = taskOperation;

// ============================================================
// FUNZIONI HELPER (anche queste da refactorare)
// ============================================================

// Helper con nome poco chiaro
export function z(id: number): Task | null {
  return x(null, 'find', id) as Task | null;
}

// Helper con side effects
export function addAndLog(title: string, prio?: number): Task | null {
  const result = x(title, 'add', prio) as Task | null;
  if (result) {
    // Side effect: log to console with formatting
    console.log('========================================');
    console.log(`NEW TASK CREATED`);
    console.log(`ID: ${result.id}`);
    console.log(`Title: ${result.t}`);
    console.log(`Priority: ${result.p === 1 ? 'HIGH' : result.p === 2 ? 'MEDIUM' : 'LOW'}`);
    console.log('========================================');
  }
  return result;
}

// Export db for testing (bad practice, but needed for demo)
export function getDb(): Task[] {
  return db;
}

export function resetDb(): void {
  db = [];
  idCounter = 1;
  stats = { add: 0, del: 0, upd: 0 };
  lastOp = '';
}
