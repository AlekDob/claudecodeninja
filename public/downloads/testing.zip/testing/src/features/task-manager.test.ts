/**
 * Test di caratterizzazione per Task Manager.
 *
 * Questi test catturano il comportamento ATTUALE del codice legacy,
 * inclusi eventuali bug. L'obiettivo è poter refactorare in sicurezza
 * verificando che il comportamento non cambi.
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import { x, resetDb, getDb } from './task-manager';

beforeEach(() => {
  // Reset database before each test
  resetDb();
  // Suppress console.log during tests
  vi.spyOn(console, 'log').mockImplementation(() => {});
});

// ============================================================
// ADD OPERATION - 'add'
// ============================================================

describe('TaskManager - Add Operation', () => {
  describe('successful add', () => {
    it('should add a task with valid title and return task object', () => {
      const result = x('Buy groceries', 'add');

      expect(result).not.toBeNull();
      expect(result.id).toBe(1);
      expect(result.t).toBe('Buy groceries');
      expect(result.done).toBe(false);
      expect(result.p).toBe(2); // default priority
      expect(result.tags).toEqual([]);
      expect(result.created).toBeInstanceOf(Date);
    });

    it('should increment id for each new task', () => {
      const task1 = x('Task 1', 'add');
      const task2 = x('Task 2', 'add');
      const task3 = x('Task 3', 'add');

      expect(task1.id).toBe(1);
      expect(task2.id).toBe(2);
      expect(task3.id).toBe(3);
    });

    it('should add task with custom priority', () => {
      const highPrio = x('Urgent task', 'add', 1);
      const lowPrio = x('Casual task', 'add', 3);

      expect(highPrio.p).toBe(1);
      expect(lowPrio.p).toBe(3);
    });

    it('should add task with tags', () => {
      const result = x('Tagged task', 'add', 2, ['work', 'important']);

      expect(result.tags).toEqual(['work', 'important']);
    });

    it('should normalize invalid priority to 2 (too low)', () => {
      const result = x('Task', 'add', 0);

      expect(result.p).toBe(2);
    });

    it('should normalize invalid priority to 2 (too high)', () => {
      const result = x('Task', 'add', 5);

      expect(result.p).toBe(2);
    });

    it('should normalize invalid priority to 2 (negative)', () => {
      const result = x('Task', 'add', -1);

      expect(result.p).toBe(2);
    });

    it('should normalize non-numeric priority to 2', () => {
      const result = x('Task', 'add', 'high');

      expect(result.p).toBe(2);
    });

    it('should store task in database', () => {
      x('Task 1', 'add');

      expect(getDb()).toHaveLength(1);
      expect(getDb()[0].t).toBe('Task 1');
    });

    it('should add task with minimum length title (1 character)', () => {
      const result = x('a', 'add');

      expect(result).not.toBeNull();
      expect(result.t).toBe('a');
    });

    it('should add task with maximum length title (100 characters)', () => {
      const longTitle = 'a'.repeat(100);
      const result = x(longTitle, 'add');

      expect(result).not.toBeNull();
      expect(result.t).toBe(longTitle);
    });

    it('should allow adding same title if previous task is completed', () => {
      const task1 = x('Duplicate title', 'add');
      x(null, 'done', task1.id);
      const task2 = x('Duplicate title', 'add');

      expect(task2).not.toBeNull();
      expect(task2.t).toBe('Duplicate title');
      expect(task2.id).toBe(2);
    });
  });

  describe('validation errors', () => {
    it('should return null for null title', () => {
      const result = x(null, 'add');

      expect(result).toBeNull();
    });

    it('should return null for undefined title', () => {
      const result = x(undefined, 'add');

      expect(result).toBeNull();
    });

    it('should return null for non-string title (number)', () => {
      const result = x(123, 'add');

      expect(result).toBeNull();
    });

    it('should return null for non-string title (object)', () => {
      const result = x({ title: 'test' }, 'add');

      expect(result).toBeNull();
    });

    it('should return null for non-string title (array)', () => {
      const result = x(['task'], 'add');

      expect(result).toBeNull();
    });

    it('should return null for title exceeding 100 characters', () => {
      const longTitle = 'a'.repeat(101);
      const result = x(longTitle, 'add');

      expect(result).toBeNull();
    });

    it('should return null for duplicate pending task title', () => {
      x('Same title', 'add');
      const duplicate = x('Same title', 'add');

      expect(duplicate).toBeNull();
    });

    it('should NOT reject empty string (bug: passes length < 1 check but fails typeof check)', () => {
      // Note: empty string passes the length check ('' has length 0 which is < 1)
      // but actually the check is a.length < 1, so '' returns null
      const result = x('', 'add');
      expect(result).toBeNull();
    });
  });

  describe('stats tracking', () => {
    it('should increment add stats counter', () => {
      x('Task 1', 'add');
      x('Task 2', 'add');

      const stats = x(null, 'stats');
      expect(stats.operations.add).toBe(2);
    });
  });
});

// ============================================================
// DELETE OPERATION - 'del', 'delete', 'rm', 'remove'
// ============================================================

describe('TaskManager - Delete Operation', () => {
  describe('aliases', () => {
    it('should delete task using "del"', () => {
      const task = x('Task to delete', 'add');
      const result = x(null, 'del', task.id);

      expect(result).toBe(true);
      expect(getDb()).toHaveLength(0);
    });

    it('should delete task using "delete"', () => {
      const task = x('Task to delete', 'add');
      const result = x(null, 'delete', task.id);

      expect(result).toBe(true);
      expect(getDb()).toHaveLength(0);
    });

    it('should delete task using "rm"', () => {
      const task = x('Task to delete', 'add');
      const result = x(null, 'rm', task.id);

      expect(result).toBe(true);
      expect(getDb()).toHaveLength(0);
    });

    it('should delete task using "remove"', () => {
      const task = x('Task to delete', 'add');
      const result = x(null, 'remove', task.id);

      expect(result).toBe(true);
      expect(getDb()).toHaveLength(0);
    });
  });

  describe('successful delete', () => {
    it('should remove task from database', () => {
      const task1 = x('Task 1', 'add');
      x('Task 2', 'add');

      x(null, 'del', task1.id);

      expect(getDb()).toHaveLength(1);
      expect(getDb()[0].t).toBe('Task 2');
    });

    it('should increment del stats counter', () => {
      const task = x('Task', 'add');
      x(null, 'del', task.id);

      const stats = x(null, 'stats');
      expect(stats.operations.del).toBe(1);
    });
  });

  describe('error cases', () => {
    it('should return false when no id provided', () => {
      x('Task', 'add');
      const result = x(null, 'del');

      expect(result).toBe(false);
    });

    it('should return false when id is null', () => {
      x('Task', 'add');
      const result = x(null, 'del', null);

      expect(result).toBe(false);
    });

    it('should return false when task not found', () => {
      x('Task', 'add');
      const result = x(null, 'del', 999);

      expect(result).toBe(false);
    });

    it('should return false when deleting already deleted task', () => {
      const task = x('Task', 'add');
      x(null, 'del', task.id);
      const result = x(null, 'del', task.id);

      expect(result).toBe(false);
    });
  });
});

// ============================================================
// COMPLETE OPERATION - 'done', 'complete', 'finish'
// ============================================================

describe('TaskManager - Complete Operation', () => {
  describe('aliases', () => {
    it('should complete task using "done"', () => {
      const task = x('Task', 'add');
      const result = x(null, 'done', task.id);

      expect(result).toBe(true);
      expect(getDb()[0].done).toBe(true);
    });

    it('should complete task using "complete"', () => {
      const task = x('Task', 'add');
      const result = x(null, 'complete', task.id);

      expect(result).toBe(true);
      expect(getDb()[0].done).toBe(true);
    });

    it('should complete task using "finish"', () => {
      const task = x('Task', 'add');
      const result = x(null, 'finish', task.id);

      expect(result).toBe(true);
      expect(getDb()[0].done).toBe(true);
    });
  });

  describe('successful completion', () => {
    it('should set done to true', () => {
      const task = x('Task', 'add');
      x(null, 'done', task.id);

      expect(getDb()[0].done).toBe(true);
    });

    it('should set completedAt timestamp', () => {
      const task = x('Task', 'add');
      x(null, 'done', task.id);

      expect(getDb()[0].completedAt).toBeInstanceOf(Date);
    });

    it('should increment upd stats counter', () => {
      const task = x('Task', 'add');
      x(null, 'done', task.id);

      const stats = x(null, 'stats');
      expect(stats.operations.upd).toBe(1);
    });
  });

  describe('error cases', () => {
    it('should return false when no id provided', () => {
      x('Task', 'add');
      const result = x(null, 'done');

      expect(result).toBe(false);
    });

    it('should return false when task not found', () => {
      x('Task', 'add');
      const result = x(null, 'done', 999);

      expect(result).toBe(false);
    });

    it('should return false when task already completed', () => {
      const task = x('Task', 'add');
      x(null, 'done', task.id);
      const result = x(null, 'done', task.id);

      expect(result).toBe(false);
    });
  });
});

// ============================================================
// UPDATE OPERATION - 'upd', 'update', 'edit'
// ============================================================

describe('TaskManager - Update Operation', () => {
  describe('aliases', () => {
    it('should update task using "upd"', () => {
      const task = x('Original', 'add');
      const result = x(null, 'upd', task.id, { title: 'Updated' });

      expect(result.t).toBe('Updated');
    });

    it('should update task using "update"', () => {
      const task = x('Original', 'add');
      const result = x(null, 'update', task.id, { title: 'Updated' });

      expect(result.t).toBe('Updated');
    });

    it('should update task using "edit"', () => {
      const task = x('Original', 'add');
      const result = x(null, 'edit', task.id, { title: 'Updated' });

      expect(result.t).toBe('Updated');
    });
  });

  describe('successful update', () => {
    it('should update title', () => {
      const task = x('Original title', 'add');
      x(null, 'upd', task.id, { title: 'New title' });

      expect(getDb()[0].t).toBe('New title');
    });

    it('should update priority', () => {
      const task = x('Task', 'add');
      x(null, 'upd', task.id, { priority: 1 });

      expect(getDb()[0].p).toBe(1);
    });

    it('should update tags', () => {
      const task = x('Task', 'add');
      x(null, 'upd', task.id, { tags: ['new', 'tags'] });

      expect(getDb()[0].tags).toEqual(['new', 'tags']);
    });

    it('should update multiple fields at once', () => {
      const task = x('Task', 'add');
      x(null, 'upd', task.id, {
        title: 'New title',
        priority: 1,
        tags: ['urgent'],
      });

      expect(getDb()[0].t).toBe('New title');
      expect(getDb()[0].p).toBe(1);
      expect(getDb()[0].tags).toEqual(['urgent']);
    });

    it('should return updated task object', () => {
      const task = x('Task', 'add');
      const result = x(null, 'upd', task.id, { title: 'Updated' });

      expect(result).toEqual(getDb()[0]);
    });

    it('should increment upd stats counter', () => {
      const task = x('Task', 'add');
      x(null, 'upd', task.id, { title: 'Updated' });

      const stats = x(null, 'stats');
      expect(stats.operations.upd).toBe(1);
    });

    it('should not modify task if no update data provided', () => {
      const task = x('Task', 'add', 2, ['tag1']);
      const result = x(null, 'upd', task.id, {});

      expect(result.t).toBe('Task');
      expect(result.p).toBe(2);
      expect(result.tags).toEqual(['tag1']);
    });

    it('should not modify task if update data is null', () => {
      const task = x('Task', 'add');
      const result = x(null, 'upd', task.id, null);

      expect(result.t).toBe('Task');
    });
  });

  describe('validation', () => {
    it('should ignore invalid title (empty string)', () => {
      const task = x('Original', 'add');
      x(null, 'upd', task.id, { title: '' });

      expect(getDb()[0].t).toBe('Original');
    });

    it('should ignore invalid title (too long)', () => {
      const task = x('Original', 'add');
      x(null, 'upd', task.id, { title: 'a'.repeat(101) });

      expect(getDb()[0].t).toBe('Original');
    });

    it('should ignore invalid title (non-string)', () => {
      const task = x('Original', 'add');
      x(null, 'upd', task.id, { title: 123 });

      expect(getDb()[0].t).toBe('Original');
    });

    it('should ignore invalid priority (too low)', () => {
      const task = x('Task', 'add', 2);
      x(null, 'upd', task.id, { priority: 0 });

      expect(getDb()[0].p).toBe(2);
    });

    it('should ignore invalid priority (too high)', () => {
      const task = x('Task', 'add', 2);
      x(null, 'upd', task.id, { priority: 4 });

      expect(getDb()[0].p).toBe(2);
    });

    it('should ignore invalid priority (non-number)', () => {
      const task = x('Task', 'add', 2);
      x(null, 'upd', task.id, { priority: 'high' });

      expect(getDb()[0].p).toBe(2);
    });

    it('should ignore invalid tags (non-array)', () => {
      const task = x('Task', 'add', 2, ['original']);
      x(null, 'upd', task.id, { tags: 'new-tag' });

      expect(getDb()[0].tags).toEqual(['original']);
    });
  });

  describe('error cases', () => {
    it('should return false when no id provided', () => {
      x('Task', 'add');
      const result = x(null, 'upd');

      expect(result).toBe(false);
    });

    it('should return false when task not found', () => {
      x('Task', 'add');
      const result = x(null, 'upd', 999, { title: 'New' });

      expect(result).toBe(false);
    });
  });
});

// ============================================================
// LIST OPERATION - 'list', 'all', 'get'
// ============================================================

describe('TaskManager - List Operation', () => {
  describe('aliases', () => {
    it('should list tasks using "list"', () => {
      x('Task 1', 'add');
      x('Task 2', 'add');
      const result = x(null, 'list');

      expect(result).toHaveLength(2);
    });

    it('should list tasks using "all"', () => {
      x('Task 1', 'add');
      x('Task 2', 'add');
      const result = x(null, 'all');

      expect(result).toHaveLength(2);
    });

    it('should list tasks using "get"', () => {
      x('Task 1', 'add');
      x('Task 2', 'add');
      const result = x(null, 'get');

      expect(result).toHaveLength(2);
    });
  });

  describe('without filters', () => {
    it('should return empty array when no tasks', () => {
      const result = x(null, 'list');

      expect(result).toEqual([]);
    });

    it('should return copy of database (not reference)', () => {
      x('Task 1', 'add');
      const result = x(null, 'list');

      result.push({ fake: 'task' });
      expect(getDb()).toHaveLength(1);
    });
  });

  describe('filter by done status', () => {
    it('should filter pending tasks (done: false)', () => {
      const task1 = x('Task 1', 'add');
      x('Task 2', 'add');
      x(null, 'done', task1.id);

      const result = x(null, 'list', { done: false });

      expect(result).toHaveLength(1);
      expect(result[0].t).toBe('Task 2');
    });

    it('should filter completed tasks (done: true)', () => {
      const task1 = x('Task 1', 'add');
      x('Task 2', 'add');
      x(null, 'done', task1.id);

      const result = x(null, 'list', { done: true });

      expect(result).toHaveLength(1);
      expect(result[0].t).toBe('Task 1');
    });
  });

  describe('filter by priority', () => {
    it('should filter by high priority (1)', () => {
      x('High', 'add', 1);
      x('Medium', 'add', 2);
      x('Low', 'add', 3);

      const result = x(null, 'list', { priority: 1 });

      expect(result).toHaveLength(1);
      expect(result[0].t).toBe('High');
    });

    it('should filter by medium priority (2)', () => {
      x('High', 'add', 1);
      x('Medium', 'add', 2);
      x('Low', 'add', 3);

      const result = x(null, 'list', { priority: 2 });

      expect(result).toHaveLength(1);
      expect(result[0].t).toBe('Medium');
    });

    it('should filter by low priority (3)', () => {
      x('High', 'add', 1);
      x('Medium', 'add', 2);
      x('Low', 'add', 3);

      const result = x(null, 'list', { priority: 3 });

      expect(result).toHaveLength(1);
      expect(result[0].t).toBe('Low');
    });
  });

  describe('filter by tag', () => {
    it('should filter tasks containing specific tag', () => {
      x('Work task', 'add', 2, ['work', 'urgent']);
      x('Home task', 'add', 2, ['home']);
      x('Both', 'add', 2, ['work', 'home']);

      const result = x(null, 'list', { tag: 'work' });

      expect(result).toHaveLength(2);
      expect(result[0].t).toBe('Work task');
      expect(result[1].t).toBe('Both');
    });

    it('should return empty array if no tasks match tag', () => {
      x('Task', 'add', 2, ['other']);

      const result = x(null, 'list', { tag: 'nonexistent' });

      expect(result).toEqual([]);
    });

    it('should handle tasks without tags', () => {
      x('No tags', 'add');
      x('With tag', 'add', 2, ['work']);

      const result = x(null, 'list', { tag: 'work' });

      expect(result).toHaveLength(1);
      expect(result[0].t).toBe('With tag');
    });
  });

  describe('sorting', () => {
    it('should sort by priority (ascending)', () => {
      x('Low', 'add', 3);
      x('High', 'add', 1);
      x('Medium', 'add', 2);

      const result = x(null, 'list', { sort: 'priority' });

      expect(result[0].t).toBe('High');
      expect(result[1].t).toBe('Medium');
      expect(result[2].t).toBe('Low');
    });

    it('should sort by created date (ascending)', () => {
      // We need to control dates for this test
      const task1 = x('First', 'add');
      const task2 = x('Second', 'add');
      const task3 = x('Third', 'add');

      const result = x(null, 'list', { sort: 'created' });

      expect(result[0].id).toBe(task1.id);
      expect(result[1].id).toBe(task2.id);
      expect(result[2].id).toBe(task3.id);
    });

    it('should sort by title (alphabetically)', () => {
      x('Zebra', 'add');
      x('Apple', 'add');
      x('Mango', 'add');

      const result = x(null, 'list', { sort: 'title' });

      expect(result[0].t).toBe('Apple');
      expect(result[1].t).toBe('Mango');
      expect(result[2].t).toBe('Zebra');
    });
  });

  describe('combined filters', () => {
    it('should apply multiple filters together', () => {
      x('High urgent', 'add', 1, ['urgent']);
      x('High normal', 'add', 1, ['normal']);
      x('Medium urgent', 'add', 2, ['urgent']);
      const task4 = x('High done', 'add', 1, ['urgent']);
      x(null, 'done', task4.id);

      const result = x(null, 'list', {
        done: false,
        priority: 1,
        tag: 'urgent',
      });

      expect(result).toHaveLength(1);
      expect(result[0].t).toBe('High urgent');
    });

    it('should filter and sort together', () => {
      x('B urgent', 'add', 2, ['urgent']);
      x('A urgent', 'add', 2, ['urgent']);
      x('C normal', 'add', 2, ['normal']);

      const result = x(null, 'list', { tag: 'urgent', sort: 'title' });

      expect(result).toHaveLength(2);
      expect(result[0].t).toBe('A urgent');
      expect(result[1].t).toBe('B urgent');
    });
  });
});

// ============================================================
// FIND OPERATION - 'find', 'getById', 'byId'
// ============================================================

describe('TaskManager - Find Operation', () => {
  describe('aliases', () => {
    it('should find task using "find"', () => {
      const task = x('Task', 'add');
      const result = x(null, 'find', task.id);

      expect(result.t).toBe('Task');
    });

    it('should find task using "getById"', () => {
      const task = x('Task', 'add');
      const result = x(null, 'getById', task.id);

      expect(result.t).toBe('Task');
    });

    it('should find task using "byId"', () => {
      const task = x('Task', 'add');
      const result = x(null, 'byId', task.id);

      expect(result.t).toBe('Task');
    });
  });

  describe('successful find', () => {
    it('should return task object when found', () => {
      const task = x('Find me', 'add', 1, ['test']);
      const result = x(null, 'find', task.id);

      expect(result).toEqual(task);
      expect(result.id).toBe(task.id);
      expect(result.t).toBe('Find me');
      expect(result.p).toBe(1);
      expect(result.tags).toEqual(['test']);
    });

    it('should find correct task among multiple', () => {
      x('Task 1', 'add');
      const task2 = x('Task 2', 'add');
      x('Task 3', 'add');

      const result = x(null, 'find', task2.id);

      expect(result.t).toBe('Task 2');
    });
  });

  describe('not found cases', () => {
    it('should return null when no id provided', () => {
      x('Task', 'add');
      const result = x(null, 'find');

      expect(result).toBeNull();
    });

    it('should return null when id is null', () => {
      x('Task', 'add');
      const result = x(null, 'find', null);

      expect(result).toBeNull();
    });

    it('should return null when id is undefined', () => {
      x('Task', 'add');
      const result = x(null, 'find', undefined);

      expect(result).toBeNull();
    });

    it('should return null when task not found', () => {
      x('Task', 'add');
      const result = x(null, 'find', 999);

      expect(result).toBeNull();
    });

    it('should return null when database is empty', () => {
      const result = x(null, 'find', 1);

      expect(result).toBeNull();
    });
  });
});

// ============================================================
// STATS OPERATION - 'stats', 'info'
// ============================================================

describe('TaskManager - Stats Operation', () => {
  describe('aliases', () => {
    it('should get stats using "stats"', () => {
      const result = x(null, 'stats');

      expect(result).toHaveProperty('total');
    });

    it('should get stats using "info"', () => {
      const result = x(null, 'info');

      expect(result).toHaveProperty('total');
    });
  });

  describe('stats values', () => {
    it('should return zero counts for empty database', () => {
      const result = x(null, 'stats');

      expect(result.total).toBe(0);
      expect(result.completed).toBe(0);
      expect(result.pending).toBe(0);
      expect(result.byPriority.high).toBe(0);
      expect(result.byPriority.medium).toBe(0);
      expect(result.byPriority.low).toBe(0);
      expect(result.operations.add).toBe(0);
      expect(result.operations.del).toBe(0);
      expect(result.operations.upd).toBe(0);
    });

    it('should count total tasks', () => {
      x('Task 1', 'add');
      x('Task 2', 'add');
      x('Task 3', 'add');

      const result = x(null, 'stats');

      expect(result.total).toBe(3);
    });

    it('should count completed and pending separately', () => {
      const task1 = x('Task 1', 'add');
      x('Task 2', 'add');
      x('Task 3', 'add');
      x(null, 'done', task1.id);

      const result = x(null, 'stats');

      expect(result.completed).toBe(1);
      expect(result.pending).toBe(2);
    });

    it('should count by priority', () => {
      x('High 1', 'add', 1);
      x('High 2', 'add', 1);
      x('Medium', 'add', 2);
      x('Low 1', 'add', 3);
      x('Low 2', 'add', 3);
      x('Low 3', 'add', 3);

      const result = x(null, 'stats');

      expect(result.byPriority.high).toBe(2);
      expect(result.byPriority.medium).toBe(1);
      expect(result.byPriority.low).toBe(3);
    });

    it('should track operation counts', () => {
      const task1 = x('Task 1', 'add');
      x('Task 2', 'add');
      x('Task 3', 'add');
      x(null, 'del', task1.id);
      const task2 = x(null, 'find', 2);
      x(null, 'upd', task2.id, { title: 'Updated' });
      x(null, 'done', task2.id);

      const result = x(null, 'stats');

      expect(result.operations.add).toBe(3);
      expect(result.operations.del).toBe(1);
      expect(result.operations.upd).toBe(2); // update + done
    });

    it('should return copy of operations object', () => {
      x('Task', 'add');
      const stats1 = x(null, 'stats');
      x('Another', 'add');
      const stats2 = x(null, 'stats');

      expect(stats1.operations.add).toBe(1);
      expect(stats2.operations.add).toBe(2);
    });
  });
});

// ============================================================
// CLEAR/RESET OPERATION - 'clear', 'reset'
// ============================================================

describe('TaskManager - Clear Operation', () => {
  describe('aliases', () => {
    it('should clear using "clear"', () => {
      x('Task', 'add');
      x(null, 'clear');

      expect(getDb()).toHaveLength(0);
    });

    it('should clear using "reset"', () => {
      x('Task', 'add');
      x(null, 'reset');

      expect(getDb()).toHaveLength(0);
    });
  });

  describe('clear behavior', () => {
    it('should return true', () => {
      const result = x(null, 'clear');

      expect(result).toBe(true);
    });

    it('should remove all tasks', () => {
      x('Task 1', 'add');
      x('Task 2', 'add');
      x('Task 3', 'add');

      x(null, 'clear');

      expect(getDb()).toHaveLength(0);
    });

    it('should reset id counter', () => {
      x('Task 1', 'add');
      x('Task 2', 'add');
      x(null, 'clear');
      const newTask = x('New task', 'add');

      expect(newTask.id).toBe(1);
    });

    it('should reset stats counters', () => {
      x('Task 1', 'add');
      x('Task 2', 'add');
      const task = x('Task 3', 'add');
      x(null, 'del', task.id);

      x(null, 'clear');
      const stats = x(null, 'stats');

      expect(stats.operations.add).toBe(0);
      expect(stats.operations.del).toBe(0);
      expect(stats.operations.upd).toBe(0);
    });

    it('should work on empty database', () => {
      const result = x(null, 'clear');

      expect(result).toBe(true);
      expect(getDb()).toHaveLength(0);
    });
  });
});

// ============================================================
// UNKNOWN OPERATION
// ============================================================

describe('TaskManager - Unknown Operation', () => {
  it('should return null for unknown operation', () => {
    const result = x(null, 'unknown');

    expect(result).toBeNull();
  });

  it('should return null for empty operation string', () => {
    const result = x(null, '');

    expect(result).toBeNull();
  });

  it('should be case sensitive (ADD should not work)', () => {
    const result = x('Task', 'ADD');

    expect(result).toBeNull();
  });

  it('should be case sensitive (Delete should not work)', () => {
    const task = x('Task', 'add');
    const result = x(null, 'Delete', task.id);

    expect(result).toBeNull();
  });
});

// ============================================================
// EDGE CASES AND SPECIAL SCENARIOS
// ============================================================

describe('TaskManager - Edge Cases', () => {
  describe('first parameter (a) handling', () => {
    it('should use first parameter as title for add operation', () => {
      const result = x('Title from a', 'add');

      expect(result.t).toBe('Title from a');
    });

    it('should ignore first parameter for other operations', () => {
      const task = x('Task', 'add');
      // First parameter is ignored for delete
      const result = x('ignored', 'del', task.id);

      expect(result).toBe(true);
      expect(getDb()).toHaveLength(0);
    });
  });

  describe('concurrent-like operations', () => {
    it('should handle rapid add operations', () => {
      for (let i = 0; i < 100; i++) {
        x(`Task ${i}`, 'add');
      }

      expect(getDb()).toHaveLength(100);
      expect(getDb()[99].id).toBe(100);
    });

    it('should handle interleaved operations', () => {
      const task1 = x('Task 1', 'add');
      const task2 = x('Task 2', 'add');
      x(null, 'done', task1.id);
      const task3 = x('Task 3', 'add');
      x(null, 'del', task2.id);
      x(null, 'upd', task3.id, { title: 'Updated Task 3' });

      expect(getDb()).toHaveLength(2);
      expect(getDb()[0].done).toBe(true);
      expect(getDb()[1].t).toBe('Updated Task 3');
    });
  });

  describe('special characters in title', () => {
    it('should handle unicode characters', () => {
      const result = x('任務 🎯 タスク', 'add');

      expect(result.t).toBe('任務 🎯 タスク');
    });

    it('should handle newlines in title', () => {
      const result = x('Line 1\nLine 2', 'add');

      expect(result.t).toBe('Line 1\nLine 2');
    });

    it('should handle special regex characters', () => {
      const result = x('Task (1) [2] {3} $4 ^5', 'add');

      expect(result.t).toBe('Task (1) [2] {3} $4 ^5');
    });
  });

  describe('data integrity', () => {
    it('should not mutate returned list array', () => {
      x('Task', 'add');
      const list = x(null, 'list');
      list[0].t = 'Mutated';

      // Original should also be mutated (this is current behavior - reference returned)
      expect(getDb()[0].t).toBe('Mutated');
    });

    it('should return same object reference in find and list', () => {
      const task = x('Task', 'add');
      const found = x(null, 'find', task.id);
      const list = x(null, 'list');

      expect(found).toBe(list[0]);
    });
  });
});
