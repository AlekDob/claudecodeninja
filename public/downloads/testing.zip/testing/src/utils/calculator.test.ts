/**
 * Test file for Calculator utilities.
 *
 * QUESTO FILE È INTENZIONALMENTE QUASI VUOTO!
 *
 * Durante la demo TDD, Claude Code genererà i test qui.
 * Il file contiene solo un test placeholder per verificare che Vitest funzioni.
 */

import { describe, it, expect } from 'vitest';
import { calculateDiscount, calculateTotal, CartItem } from './calculator';

describe('Calculator - Setup Verification', () => {
  it('should verify test environment is working', () => {
    expect(1 + 1).toBe(2);
  });
});

// ============================================================
// TEST PER calculateDiscount - FIXED
// ============================================================
describe('calculateDiscount', () => {
  describe('casi base', () => {
    it('dovrebbe calcolare correttamente uno sconto del 10%', () => {
      expect(calculateDiscount(100, 10)).toBe(90);
    });

    it('dovrebbe calcolare correttamente uno sconto del 50%', () => {
      expect(calculateDiscount(100, 50)).toBe(50);
    });

    it('dovrebbe restituire il prezzo originale con sconto 0%', () => {
      expect(calculateDiscount(100, 0)).toBe(100);
    });

    it('dovrebbe restituire 0 con sconto 100%', () => {
      expect(calculateDiscount(100, 100)).toBe(0);
    });
  });

  describe('FIX 1: validazione prezzi negativi', () => {
    it('dovrebbe lanciare errore per prezzi negativi', () => {
      // FIX: ora lancia un errore invece di restituire valori negativi
      expect(() => calculateDiscount(-100, 10)).toThrow('Price cannot be negative');
    });

    it('dovrebbe lanciare errore per prezzi molto negativi', () => {
      expect(() => calculateDiscount(-0.01, 10)).toThrow('Price cannot be negative');
    });

    it('dovrebbe gestire prezzo zero correttamente', () => {
      expect(calculateDiscount(0, 50)).toBe(0);
    });
  });

  describe('FIX 2: sconti clampati a 0-100%', () => {
    it('dovrebbe clampare sconti maggiori di 100% a 100%', () => {
      // FIX: sconto 150% viene clampato a 100%, risultato = 0
      const result = calculateDiscount(100, 150);
      expect(result).toBe(0);
    });

    it('dovrebbe clampare sconti negativi a 0%', () => {
      // FIX: sconto -20% viene clampato a 0%, prezzo rimane invariato
      const result = calculateDiscount(100, -20);
      expect(result).toBe(100);
    });

    it('dovrebbe gestire sconto esattamente 100%', () => {
      expect(calculateDiscount(50, 100)).toBe(0);
    });

    it('dovrebbe gestire sconto esattamente 0%', () => {
      expect(calculateDiscount(50, 0)).toBe(50);
    });
  });

  describe('FIX 3: precisione floating point', () => {
    it('dovrebbe gestire correttamente 19.99 con sconto 10%', () => {
      // FIX: arrotondato a 2 decimali
      const result = calculateDiscount(19.99, 10);
      expect(result).toBe(17.99);
    });

    it('dovrebbe gestire correttamente 0.3 con sconto 10%', () => {
      const result = calculateDiscount(0.3, 10);
      expect(result).toBe(0.27);
    });

    it('dovrebbe restituire un valore con al massimo 2 decimali', () => {
      const result = calculateDiscount(19.99, 15);
      const decimals = (result.toString().split('.')[1] || '').length;
      expect(decimals).toBeLessThanOrEqual(2);
    });

    it('dovrebbe arrotondare correttamente 33.33 con sconto 33%', () => {
      // 33.33 * 0.33 = 10.9989, 33.33 - 10.9989 = 22.3311
      // Arrotondato: 22.33
      const result = calculateDiscount(33.33, 33);
      expect(result).toBe(22.33);
    });
  });

  describe('FIX: input invalidi (NaN, Infinity)', () => {
    it('dovrebbe lanciare errore per NaN come prezzo', () => {
      expect(() => calculateDiscount(NaN, 10)).toThrow('Price must be a finite number');
    });

    it('dovrebbe lanciare errore per Infinity come prezzo', () => {
      expect(() => calculateDiscount(Infinity, 10)).toThrow('Price must be a finite number');
    });

    it('dovrebbe lanciare errore per -Infinity come prezzo', () => {
      // -Infinity è anche < 0, quindi viene catturato dal check negativi
      expect(() => calculateDiscount(-Infinity, 10)).toThrow('Price cannot be negative');
    });
  });

  describe('test di regressione', () => {
    it('REGRESSION: prezzo negativo non deve mai restituire valore', () => {
      // Previene regressione del bug originale
      expect(() => calculateDiscount(-1, 10)).toThrow();
    });

    it('REGRESSION: sconto 150% non deve dare prezzo negativo', () => {
      // Previene regressione: prima restituiva -50
      const result = calculateDiscount(100, 150);
      expect(result).toBeGreaterThanOrEqual(0);
    });

    it('REGRESSION: precisione deve essere sempre <= 2 decimali', () => {
      // Test con valori che causavano problemi di precisione
      const testCases = [
        { price: 19.99, discount: 10 },
        { price: 29.99, discount: 15 },
        { price: 0.1, discount: 30 },
        { price: 99.99, discount: 7 },
      ];

      for (const { price, discount } of testCases) {
        const result = calculateDiscount(price, discount);
        const decimals = (result.toString().split('.')[1] || '').length;
        expect(decimals).toBeLessThanOrEqual(2);
      }
    });
  });
});

// ============================================================
// TEST PER calculateTotal - FIXED
// ============================================================
describe('calculateTotal', () => {
  describe('casi base', () => {
    it('dovrebbe calcolare il totale di più prodotti', () => {
      const items: CartItem[] = [
        { name: 'Prodotto A', price: 10, quantity: 2 },
        { name: 'Prodotto B', price: 5, quantity: 3 },
      ];
      // 10*2 + 5*3 = 20 + 15 = 35
      expect(calculateTotal(items)).toBe(35);
    });

    it('dovrebbe gestire un array vuoto', () => {
      expect(calculateTotal([])).toBe(0);
    });
  });

  describe('FIX: off-by-one error corretto', () => {
    it('dovrebbe includere TUTTI gli elementi, incluso l\'ultimo', () => {
      // FIX: ora usa i < items.length (non più length - 1)
      const items: CartItem[] = [
        { name: 'Prodotto A', price: 10, quantity: 1 },
        { name: 'Prodotto B', price: 20, quantity: 1 },
        { name: 'Prodotto C', price: 30, quantity: 1 },
      ];
      expect(calculateTotal(items)).toBe(60);
    });

    it('dovrebbe calcolare correttamente con un solo elemento', () => {
      // FIX: ora funziona correttamente con array di 1 elemento
      const items: CartItem[] = [
        { name: 'Prodotto singolo', price: 50, quantity: 2 },
      ];
      expect(calculateTotal(items)).toBe(100);
    });

    it('dovrebbe calcolare correttamente con due elementi', () => {
      const items: CartItem[] = [
        { name: 'Primo', price: 25, quantity: 1 },
        { name: 'Secondo', price: 25, quantity: 1 },
      ];
      expect(calculateTotal(items)).toBe(50);
    });
  });

  describe('edge cases', () => {
    it('dovrebbe gestire quantità zero', () => {
      const items: CartItem[] = [
        { name: 'Prodotto', price: 100, quantity: 0 },
      ];
      expect(calculateTotal(items)).toBe(0);
    });

    it('dovrebbe gestire prezzi decimali', () => {
      const items: CartItem[] = [
        { name: 'Prodotto', price: 9.99, quantity: 3 },
      ];
      expect(calculateTotal(items)).toBeCloseTo(29.97, 2);
    });

    it('dovrebbe gestire grandi quantità', () => {
      const items: CartItem[] = [
        { name: 'Prodotto', price: 0.01, quantity: 10000 },
      ];
      expect(calculateTotal(items)).toBeCloseTo(100, 2);
    });

    it('dovrebbe gestire molti elementi nel carrello', () => {
      const items: CartItem[] = Array.from({ length: 100 }, (_, i) => ({
        name: `Prodotto ${i}`,
        price: 1,
        quantity: 1,
      }));
      expect(calculateTotal(items)).toBe(100);
    });
  });

  describe('test di regressione', () => {
    it('REGRESSION: singolo elemento deve essere contato', () => {
      // Previene regressione del bug off-by-one
      const items: CartItem[] = [{ name: 'Solo', price: 42, quantity: 1 }];
      expect(calculateTotal(items)).toBe(42);
    });

    it('REGRESSION: ultimo elemento deve sempre essere incluso', () => {
      // Test con vari numeri di elementi
      for (let count = 1; count <= 5; count++) {
        const items: CartItem[] = Array.from({ length: count }, () => ({
          name: 'Item',
          price: 10,
          quantity: 1,
        }));
        expect(calculateTotal(items)).toBe(count * 10);
      }
    });

    it('REGRESSION: array di 2 elementi deve sommare entrambi', () => {
      const items: CartItem[] = [
        { name: 'A', price: 100, quantity: 1 },
        { name: 'B', price: 200, quantity: 1 },
      ];
      expect(calculateTotal(items)).toBe(300);
    });
  });
});

// ============================================================
// SEZIONE TDD DEMO: I test verranno aggiunti qui
// ============================================================

// Durante la demo, chiederemo a Claude Code:
// "Genera test per calculateDiscount considerando edge cases"
//
// Claude Code aggiungerà test per:
// - Prezzi negativi
// - Sconti > 100%
// - Precisione floating point
// - Input invalidi (NaN, Infinity)

// describe('calculateDiscount', () => {
//   // TEST DA GENERARE DURANTE LA DEMO
// });

// describe('calculateTotal', () => {
//   // TEST DA GENERARE DURANTE LA DEMO
// });

import { validateCoupon, Coupon } from './calculator';

describe('validateCoupon', () => {
  // Helper per creare un coupon valido di base
  const createValidCoupon = (overrides: Partial<Coupon> = {}): Coupon => ({
    code: 'TESTCOUPON',
    discountPercent: 10,
    minPurchase: 50,
    expiresAt: new Date('2025-12-31'),
    maxUses: 100,
    currentUses: 0,
    ...overrides,
  });

  const currentDate = new Date('2025-06-15');

  // ============================================================
  // CASI DI SUCCESSO
  // ============================================================
  describe('casi di successo', () => {
    it('dovrebbe validare un coupon con tutti i requisiti soddisfatti', () => {
      const coupon = createValidCoupon();
      const result = validateCoupon(coupon, 100, currentDate);

      expect(result.valid).toBe(true);
      expect(result.reason).toBeUndefined();
    });

    it('dovrebbe validare un coupon quando cartTotal è esattamente uguale a minPurchase', () => {
      const coupon = createValidCoupon({ minPurchase: 50 });
      const result = validateCoupon(coupon, 50, currentDate);

      expect(result.valid).toBe(true);
    });

    it('dovrebbe validare un coupon quando cartTotal è maggiore di minPurchase', () => {
      const coupon = createValidCoupon({ minPurchase: 50 });
      const result = validateCoupon(coupon, 150, currentDate);

      expect(result.valid).toBe(true);
    });

    it('dovrebbe validare un coupon con currentUses = 0', () => {
      const coupon = createValidCoupon({ maxUses: 10, currentUses: 0 });
      const result = validateCoupon(coupon, 100, currentDate);

      expect(result.valid).toBe(true);
    });

    it('dovrebbe validare un coupon con currentUses = maxUses - 1', () => {
      const coupon = createValidCoupon({ maxUses: 10, currentUses: 9 });
      const result = validateCoupon(coupon, 100, currentDate);

      expect(result.valid).toBe(true);
    });

    it('dovrebbe validare un coupon che scade domani', () => {
      const tomorrow = new Date(currentDate);
      tomorrow.setDate(tomorrow.getDate() + 1);
      const coupon = createValidCoupon({ expiresAt: tomorrow });
      const result = validateCoupon(coupon, 100, currentDate);

      expect(result.valid).toBe(true);
    });

    it('dovrebbe validare un coupon con minPurchase = 0', () => {
      const coupon = createValidCoupon({ minPurchase: 0 });
      const result = validateCoupon(coupon, 0, currentDate);

      expect(result.valid).toBe(true);
    });
  });

  // ============================================================
  // FALLIMENTI: COUPON SCADUTO
  // ============================================================
  describe('coupon scaduto', () => {
    it('dovrebbe rifiutare un coupon scaduto ieri', () => {
      const yesterday = new Date(currentDate);
      yesterday.setDate(yesterday.getDate() - 1);
      const coupon = createValidCoupon({ expiresAt: yesterday });
      const result = validateCoupon(coupon, 100, currentDate);

      expect(result.valid).toBe(false);
      expect(result.reason).toContain('scadut');
    });

    it('dovrebbe rifiutare un coupon scaduto da tempo', () => {
      const longAgo = new Date('2020-01-01');
      const coupon = createValidCoupon({ expiresAt: longAgo });
      const result = validateCoupon(coupon, 100, currentDate);

      expect(result.valid).toBe(false);
      expect(result.reason).toContain('scadut');
    });

    it('dovrebbe rifiutare un coupon che scade esattamente ora (stesso timestamp)', () => {
      const coupon = createValidCoupon({ expiresAt: new Date(currentDate) });
      const result = validateCoupon(coupon, 100, currentDate);

      expect(result.valid).toBe(false);
      expect(result.reason).toContain('scadut');
    });
  });

  // ============================================================
  // FALLIMENTI: IMPORTO MINIMO NON RAGGIUNTO
  // ============================================================
  describe('importo minimo non raggiunto', () => {
    it('dovrebbe rifiutare quando cartTotal < minPurchase', () => {
      const coupon = createValidCoupon({ minPurchase: 100 });
      const result = validateCoupon(coupon, 50, currentDate);

      expect(result.valid).toBe(false);
      expect(result.reason).toContain('minim');
    });

    it('dovrebbe rifiutare quando cartTotal è 0 e minPurchase > 0', () => {
      const coupon = createValidCoupon({ minPurchase: 50 });
      const result = validateCoupon(coupon, 0, currentDate);

      expect(result.valid).toBe(false);
      expect(result.reason).toContain('minim');
    });

    it('dovrebbe rifiutare quando cartTotal è leggermente inferiore a minPurchase', () => {
      const coupon = createValidCoupon({ minPurchase: 100 });
      const result = validateCoupon(coupon, 99.99, currentDate);

      expect(result.valid).toBe(false);
      expect(result.reason).toContain('minim');
    });
  });

  // ============================================================
  // FALLIMENTI: UTILIZZI MASSIMI SUPERATI
  // ============================================================
  describe('utilizzi massimi superati', () => {
    it('dovrebbe rifiutare quando currentUses >= maxUses', () => {
      const coupon = createValidCoupon({ maxUses: 10, currentUses: 10 });
      const result = validateCoupon(coupon, 100, currentDate);

      expect(result.valid).toBe(false);
      expect(result.reason).toContain('utilizz');
    });

    it('dovrebbe rifiutare quando currentUses > maxUses', () => {
      const coupon = createValidCoupon({ maxUses: 10, currentUses: 15 });
      const result = validateCoupon(coupon, 100, currentDate);

      expect(result.valid).toBe(false);
      expect(result.reason).toContain('utilizz');
    });

    it('dovrebbe rifiutare quando maxUses = 0 (coupon mai utilizzabile)', () => {
      const coupon = createValidCoupon({ maxUses: 0, currentUses: 0 });
      const result = validateCoupon(coupon, 100, currentDate);

      expect(result.valid).toBe(false);
      expect(result.reason).toContain('utilizz');
    });

    it('dovrebbe rifiutare quando maxUses = 1 e currentUses = 1', () => {
      const coupon = createValidCoupon({ maxUses: 1, currentUses: 1 });
      const result = validateCoupon(coupon, 100, currentDate);

      expect(result.valid).toBe(false);
      expect(result.reason).toContain('utilizz');
    });
  });

  // ============================================================
  // EDGE CASES
  // ============================================================
  describe('edge cases', () => {
    it('dovrebbe gestire valori molto grandi per cartTotal', () => {
      const coupon = createValidCoupon({ minPurchase: 1000000 });
      const result = validateCoupon(coupon, 1000000, currentDate);

      expect(result.valid).toBe(true);
    });

    it('dovrebbe gestire numeri decimali con precisione', () => {
      const coupon = createValidCoupon({ minPurchase: 49.99 });
      const result = validateCoupon(coupon, 49.99, currentDate);

      expect(result.valid).toBe(true);
    });

    it('dovrebbe gestire date ai limiti (inizio anno)', () => {
      const startOfYear = new Date('2025-01-01T00:00:00.000Z');
      const coupon = createValidCoupon({ expiresAt: new Date('2025-01-02') });
      const result = validateCoupon(coupon, 100, startOfYear);

      expect(result.valid).toBe(true);
    });

    it('dovrebbe gestire date ai limiti (fine anno)', () => {
      const endOfYear = new Date('2025-12-31T23:59:59.999Z');
      const coupon = createValidCoupon({ expiresAt: new Date('2026-01-01') });
      const result = validateCoupon(coupon, 100, endOfYear);

      expect(result.valid).toBe(true);
    });

    it('dovrebbe usare la data corrente come default quando non specificata', () => {
      const coupon = createValidCoupon({ expiresAt: new Date('2099-12-31') });
      const result = validateCoupon(coupon, 100);

      expect(result.valid).toBe(true);
    });

    it('dovrebbe gestire maxUses molto alto', () => {
      const coupon = createValidCoupon({ maxUses: 1000000, currentUses: 999999 });
      const result = validateCoupon(coupon, 100, currentDate);

      expect(result.valid).toBe(true);
    });

    it('dovrebbe fallire con millisecondi di differenza nella scadenza', () => {
      const exactTime = new Date('2025-06-15T12:00:00.000Z');
      const coupon = createValidCoupon({ expiresAt: exactTime });
      const result = validateCoupon(coupon, 100, exactTime);

      expect(result.valid).toBe(false);
      expect(result.reason).toContain('scadut');
    });

    it('dovrebbe validare con un millisecondo di margine', () => {
      const exactTime = new Date('2025-06-15T12:00:00.000Z');
      const expiresAt = new Date('2025-06-15T12:00:00.001Z');
      const coupon = createValidCoupon({ expiresAt });
      const result = validateCoupon(coupon, 100, exactTime);

      expect(result.valid).toBe(true);
    });
  });

  // ============================================================
  // COMBINAZIONI DI FALLIMENTI
  // ============================================================
  describe('combinazioni di fallimenti', () => {
    it('dovrebbe riportare un errore anche con più condizioni non soddisfatte', () => {
      const yesterday = new Date(currentDate);
      yesterday.setDate(yesterday.getDate() - 1);
      const coupon = createValidCoupon({
        expiresAt: yesterday,
        minPurchase: 1000,
        maxUses: 5,
        currentUses: 5,
      });
      const result = validateCoupon(coupon, 10, currentDate);

      expect(result.valid).toBe(false);
      expect(result.reason).toBeDefined();
    });
  });
});
