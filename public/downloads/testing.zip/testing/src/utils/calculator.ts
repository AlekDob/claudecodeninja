/**
 * Calculator utilities.
 *
 * BUGS FIXED:
 * - FIX 1: calculateDiscount now validates negative prices (throws error)
 * - FIX 2: calculateDiscount now clamps discount to 0-100% range
 * - FIX 3: calculateDiscount now rounds to 2 decimal places for currency precision
 * - FIX 4: calculateTotal off-by-one error fixed (was using length-1)
 * - BUG 5: applyBulkDiscount has race condition potential (not yet fixed)
 */

// ============================================================
// FUNZIONE 1: calculateDiscount - FIXED
// ============================================================

/**
 * Calculates the discounted price.
 * @param price - Original price (must be >= 0)
 * @param discountPercent - Discount percentage (clamped to 0-100)
 * @returns Discounted price rounded to 2 decimal places
 * @throws Error if price is negative, NaN, or Infinity
 */
export function calculateDiscount(price: number, discountPercent: number): number {
  // FIX 1: Validate price - reject negative, NaN, and Infinity
  if (price < 0) {
    throw new Error('Price cannot be negative');
  }
  if (!Number.isFinite(price)) {
    throw new Error('Price must be a finite number');
  }

  // FIX 2: Clamp discount to valid range 0-100%
  const clampedDiscount = Math.max(0, Math.min(100, discountPercent));

  // FIX 3: Round to 2 decimal places for currency precision
  const discountAmount = price * clampedDiscount / 100;
  const result = price - discountAmount;

  return Math.round(result * 100) / 100;
}


// ============================================================
// FUNZIONE 2: calculateTotal - FIXED
// ============================================================

export interface CartItem {
  name: string;
  price: number;
  quantity: number;
}

/**
 * Calculates total price of cart items.
 * @param items - Array of cart items
 * @returns Total price
 */
export function calculateTotal(items: CartItem[]): number {
  let total = 0;
  for (let i = 0; i < items.length; i++) {
    total += items[i].price * items[i].quantity;
  }
  return total;
}


// ============================================================
// FUNZIONE 3: applyBulkDiscount - con problemi di concorrenza
// ============================================================

// Simulated database state (for demo purposes)
let inventoryCache: Map<string, number> = new Map();

/**
 * Applies bulk discount if quantity threshold is met.
 * Has potential race condition issues.
 */
export async function applyBulkDiscount(
  productId: string,
  requestedQty: number,
  basePrice: number
): Promise<{ success: boolean; finalPrice: number; message: string }> {
  // Simula latenza database
  await new Promise(resolve => setTimeout(resolve, 10));

  const availableQty = inventoryCache.get(productId) ?? 0;

  // BUG 5: Race condition - check e update non sono atomici
  // Due chiamate simultanee potrebbero entrambe passare il check
  if (requestedQty > availableQty) {
    return {
      success: false,
      finalPrice: 0,
      message: `Insufficient inventory: requested ${requestedQty}, available ${availableQty}`
    };
  }

  // Simula altra latenza (window per race condition)
  await new Promise(resolve => setTimeout(resolve, 10));

  // Update inventory (non atomico!)
  inventoryCache.set(productId, availableQty - requestedQty);

  // Apply bulk discount: 10% off for 5+ items, 20% off for 10+ items
  let discount = 0;
  if (requestedQty >= 10) {
    discount = 20;
  } else if (requestedQty >= 5) {
    discount = 10;
  }

  const finalPrice = basePrice * requestedQty * (1 - discount / 100);

  return {
    success: true,
    finalPrice,
    message: `Applied ${discount}% bulk discount`
  };
}

// Helper to reset inventory for testing
export function setInventory(productId: string, quantity: number): void {
  inventoryCache.set(productId, quantity);
}

export function getInventory(productId: string): number {
  return inventoryCache.get(productId) ?? 0;
}

export function clearInventory(): void {
  inventoryCache.clear();
}


// ============================================================
// FUNZIONE 4: validateCoupon - per TDD demo
// ============================================================

// Questa funzione sarà implementata durante la demo TDD
// Il file test conterrà i test, questa funzione sarà vuota inizialmente

export interface Coupon {
  code: string;
  discountPercent: number;
  minPurchase: number;
  expiresAt: Date;
  maxUses: number;
  currentUses: number;
}

export type CouponValidationResult = { valid: boolean; reason?: string };

const valid = (): CouponValidationResult => ({ valid: true });
const invalid = (reason: string): CouponValidationResult => ({ valid: false, reason });

const isExpired = (coupon: Coupon, currentDate: Date): boolean =>
  coupon.expiresAt <= currentDate;

const meetsMinimumPurchase = (cartTotal: number, minPurchase: number): boolean =>
  cartTotal >= minPurchase;

const hasUsesRemaining = (coupon: Coupon): boolean =>
  coupon.currentUses < coupon.maxUses;

/**
 * Validates a coupon against cart and date constraints.
 * Checks expiration, minimum purchase amount, and usage limits.
 */
export function validateCoupon(
  coupon: Coupon,
  cartTotal: number,
  currentDate: Date = new Date()
): CouponValidationResult {
  if (isExpired(coupon, currentDate)) {
    return invalid(
      `Coupon "${coupon.code}" scaduto il ${coupon.expiresAt.toLocaleDateString('it-IT')}`
    );
  }

  if (!meetsMinimumPurchase(cartTotal, coupon.minPurchase)) {
    return invalid(
      `Importo minimo non raggiunto: €${cartTotal.toFixed(2)} < €${coupon.minPurchase.toFixed(2)}`
    );
  }

  if (!hasUsesRemaining(coupon)) {
    return invalid(
      `Numero massimo di utilizzi raggiunto (${coupon.maxUses})`
    );
  }

  return valid();
}
