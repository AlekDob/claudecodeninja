# Script Demo: Testing & Refactoring Workflow con Claude Code

> **Durata totale**: 60-75 minuti
> **Audience**: Sviluppatori che vogliono imparare a usare Claude Code per testing, refactoring e debugging

---

## Setup Iniziale (5 minuti)

### Prima della demo

```bash
# Nella directory del progetto
cd testing

# Installa dipendenze
npm install

# Verifica che i test funzionino
npm test
```

**Output atteso**: 2 test passano (setup verification per calculator e task-manager)

### Presenta il progetto

> "Oggi vi mostro come Claude Code trasforma il modo in cui scriviamo test, refactoriamo codice legacy e debugghiamo bug. Useremo due esempi concreti: un modulo calculator con bug nascosti e un task manager scritto male che dobbiamo sistemare."

---

## FASE 1: Test-Driven Development (15 minuti)

### 1.1 Introduzione al TDD (2 min)

> "Il TDD segue un ciclo preciso: RED → GREEN → REFACTOR. Scrivere test PRIMA del codice sembra controintuitivo, ma costringe a pensare a COSA deve fare il codice prima di pensare a COME implementarlo."

Mostra il file `src/utils/calculator.ts` e la funzione `validateCoupon` che è solo uno stub:

```typescript
export function validateCoupon(
  coupon: Coupon,
  cartTotal: number,
  currentDate: Date = new Date()
): { valid: boolean; reason?: string } {
  // STUB: Da implementare durante la demo TDD
  return { valid: false, reason: 'Not implemented' };
}
```

### 1.2 Fase RED: Generare Test (5 min)

**PROMPT da usare con Claude Code:**

```
Genera test completi per la funzione validateCoupon in src/utils/calculator.ts.
La funzione deve validare un coupon verificando:
- Il coupon non sia scaduto (expiresAt > currentDate)
- Il carrello raggiunga l'importo minimo (cartTotal >= minPurchase)
- Il coupon non abbia superato il numero massimo di utilizzi (currentUses < maxUses)

Genera test per:
1. Tutti i casi di successo
2. Ogni tipo di fallimento
3. Edge cases (valori limite, date esatte, etc.)

Scrivi i test in src/utils/calculator.test.ts usando Vitest.
```

**Attendi che Claude Code generi i test**

> "Notate come Claude Code ha pensato automaticamente a edge cases che potremmo dimenticare: cosa succede se il coupon scade OGGI? E se currentUses === maxUses?"

**Esegui i test:**

```bash
npm test
```

**Output atteso**: Tutti i test nuovi FALLISCONO (rosso) perché `validateCoupon` restituisce sempre `{ valid: false }`

> "Questo è il RED del ciclo TDD. I test definiscono il comportamento che vogliamo, ma il codice non esiste ancora."

### 1.3 Fase GREEN: Implementazione Minima (5 min)

**PROMPT da usare con Claude Code:**

```
Implementa la funzione validateCoupon in src/utils/calculator.ts per far passare tutti i test.
Scrivi il codice minimo necessario per far passare i test, senza over-engineering.
```

**Attendi l'implementazione**

**Esegui i test:**

```bash
npm test
```

**Output atteso**: Tutti i test passano (verde)

> "GREEN! Il codice fa esattamente quello che i test richiedono, niente di più. Questo è il potere del TDD: implementazione guidata dai requisiti."

### 1.4 Fase REFACTOR: Miglioramento (3 min)

**PROMPT da usare con Claude Code:**

```
Refactora la funzione validateCoupon per:
- Migliore leggibilità
- Messaggi di errore più descrittivi
- Eventuale estrazione di helper functions se necessario

Mantieni tutti i test verdi.
```

**Esegui i test dopo il refactoring:**

```bash
npm test
```

**Output atteso**: Tutti i test continuano a passare

> "REFACTOR completo. Il codice è più leggibile ma il comportamento è identico. I test ci danno la sicurezza di refactorare senza paura."

---

## FASE 2: Debugging Sistematico (15 minuti)

### 2.1 Scoprire i Bug (3 min)

> "Ora passiamo a del codice con bug nascosti. Il file calculator.ts ha diversi bug intenzionali. Vediamo come Claude Code ci aiuta a trovarli."

**PROMPT da usare con Claude Code:**

```
Analizza le funzioni calculateDiscount e calculateTotal in src/utils/calculator.ts.
Genera test che potrebbero fallire per scoprire bug nascosti.
Considera:
- Edge cases (valori negativi, zero, limiti)
- Input invalidi
- Precisione numerica
- Array vuoti o con un solo elemento
```

**Attendi che Claude Code generi test**

**Esegui i test:**

```bash
npm test
```

**Output atteso**: Alcuni test falliscono, rivelando i bug!

### 2.2 Tecnica dei 5 Perché (5 min)

> "Un test fallisce su calculateTotal. Invece di fixare subito, usiamo la tecnica dei 5 Perché per trovare la root cause."

**PROMPT da usare con Claude Code:**

```
Il test per calculateTotal fallisce. Applica la tecnica dei 5 Perché:

Test che fallisce: calculateTotal([{name: 'A', price: 10, quantity: 1}]) dovrebbe restituire 10, ma restituisce 0

Analizza:
1. Perché restituisce 0?
2. Perché [continua l'analisi]...
...fino alla root cause

Poi proponi il fix e un test di regressione per prevenire che il bug si ripresenti.
```

**Claude Code dovrebbe identificare:**
- Il bug è un off-by-one error nel loop: `i < items.length - 1` invece di `i < items.length`
- L'ultimo elemento viene sempre saltato

### 2.3 Fix e Prevenzione (7 min)

**PROMPT da usare con Claude Code:**

```
Fixa tutti i bug identificati in calculateDiscount e calculateTotal:
1. Off-by-one error in calculateTotal
2. Prezzi negativi accettati in calculateDiscount
3. Sconti > 100% accettati in calculateDiscount
4. Problemi di precisione floating point

Per ogni fix:
- Correggi il codice
- Aggiungi un test di regressione
- Documenta cosa è stato fixato
```

**Esegui i test:**

```bash
npm test
```

**Output atteso**: Tutti i test passano

> "Ora abbiamo test che prevengono questi bug in futuro. Se qualcuno reintroduce l'off-by-one error, il test fallirà immediatamente."

---

## FASE 3: Refactoring Sicuro (20 minuti)

### 3.1 Analisi Codice Legacy (3 min)

Apri `src/features/task-manager.ts`:

> "Questo è un esempio di codice legacy 'realistico'. Guardate questa funzione `x()`. Nomi incomprensibili, 200 righe, fa 10 cose diverse. Come lo sistemiamo SENZA romperlo?"

**Mostra alcuni problemi:**
- Funzione chiamata `x()`
- Parametri `a`, `b`, `c`, `d`
- Magic numbers (1, 2, 3 per priority)
- Nessun tipo TypeScript
- Variabili globali (`db`, `stats`)

### 3.2 Safety Net: Test di Caratterizzazione (7 min)

> "Prima di toccare QUALSIASI riga, creiamo una 'safety net'. I test di caratterizzazione catturano il comportamento ATTUALE, anche se è sbagliato."

**PROMPT da usare con Claude Code:**

```
Genera test di caratterizzazione completi per la funzione x() in src/features/task-manager.ts.

Devo catturare il comportamento ATTUALE del codice (anche se ha bug) per poter refactorare in sicurezza.

Testa tutte le operazioni:
- 'add': aggiunta task con validazione
- 'del'/'delete'/'rm'/'remove': rimozione task
- 'done'/'complete'/'finish': completamento task
- 'upd'/'update'/'edit': modifica task
- 'list'/'all'/'get': lista con filtri
- 'find'/'getById'/'byId': ricerca per id
- 'stats'/'info': statistiche
- 'clear'/'reset': reset database

Include test per:
- Casi di successo
- Casi di errore (input invalidi)
- Edge cases
```

**Esegui i test:**

```bash
npm test
```

**Output atteso**: Tutti i test passano (catturano comportamento attuale)

> "Safety net pronta! Ora possiamo refactorare con confidenza."

### 3.3 Refactoring Incrementale (10 min)

> "Refactoriamo UN PEZZO ALLA VOLTA. Dopo OGNI modifica, eseguiamo i test."

**Step 1: Rinomina funzione e parametri**

**PROMPT:**
```
Refactora la funzione x() in task-manager.ts:
Step 1: Rinomina la funzione da x() a taskOperation() e i parametri:
- a → data
- b → operation
- c → id
- d → options

NON cambiare la logica interna ancora. Solo rinominare.
```

```bash
npm test  # Deve passare
```

**Step 2: Extract Method per operazione 'add'**

**PROMPT:**
```
Estrai la logica dell'operazione 'add' in una funzione separata chiamata addTask().
Mantieni taskOperation() come dispatcher che chiama addTask().
```

```bash
npm test  # Deve passare
```

**Step 3: Aggiungi TypeScript types**

**PROMPT:**
```
Aggiungi TypeScript types appropriati:
- Interface Task per i task
- Type Priority = 'high' | 'medium' | 'low' invece di magic numbers
- Type per le operazioni supportate
- Rimuovi tutti gli 'any'
```

```bash
npm test  # Deve passare
```

**Step 4: Estrai altre operazioni**

**PROMPT:**
```
Estrai le altre operazioni in funzioni separate:
- deleteTask()
- completeTask()
- updateTask()
- listTasks()
- findTask()
- getStats()

Mantieni la stessa logica, solo organizzazione migliore.
```

```bash
npm test  # Deve passare
```

> "Dopo 4 step di refactoring, il codice è enormemente più leggibile, ma il comportamento è IDENTICO. I test ce lo garantiscono."

---

## FASE 4: Code Review con AI (10 minuti)

### 4.1 Simulazione Pull Request (3 min)

> "Immaginiamo che un collega abbia scritto questo codice e dobbiamo fare review."

Crea un file temporaneo con codice problematico:

```typescript
// Mostra questo codice come "PR da revieware"
async function processPayment(userId: string, amount: number) {
  const query = `SELECT * FROM users WHERE id = '${userId}'`;  // SQL Injection!
  const user = await db.query(query);

  if (amount > 0) {
    await chargeCard(user.cardNumber, amount);
    console.log(`Charged ${amount} to user ${userId}`);  // Log di dati sensibili
  }

  return { success: true };  // Nessun error handling
}
```

### 4.2 Review con Claude Code (7 min)

**PROMPT da usare con Claude Code:**

```
Fai una code review completa di questo codice come se fosse una Pull Request:

```typescript
async function processPayment(userId: string, amount: number) {
  const query = `SELECT * FROM users WHERE id = '${userId}'`;
  const user = await db.query(query);

  if (amount > 0) {
    await chargeCard(user.cardNumber, amount);
    console.log(`Charged ${amount} to user ${userId}`);
  }

  return { success: true };
}
```

Analizza:
- Vulnerabilità security (OWASP Top 10)
- Error handling
- Logging appropriato
- Best practices mancanti
- Test coverage suggerita

Formatta l'output come una vera code review con:
🔴 CRITICAL (blocca merge)
🟡 WARNING (da fixare)
🟢 SUGGESTIONS (nice to have)
```

**Claude Code dovrebbe identificare:**
- 🔴 SQL Injection vulnerability
- 🔴 Logging di dati sensibili (cardNumber)
- 🟡 Nessun error handling
- 🟡 Nessuna validazione input
- 🟢 Mancano test

> "In 30 secondi Claude Code ha trovato una vulnerabilità SQL injection critica che in una review manuale potrebbe sfuggire. Questo non sostituisce la review umana, ma la potenzia."

---

## FASE 5: Automazione con GitLab CI/CD (15 minuti)

> "Ora integriamo il progetto con GitLab CI/CD. L'ambiente demo GitLab completo è già configurato in `/Users/al/buffer/al/foody/gitlab/`"

### 5.1 Anatomia Pipeline GitLab (5 min)

Mostra il file `.gitlab-ci.yml` già presente nel progetto:

```bash
cat .gitlab-ci.yml
```

**Spiega ogni sezione:**

```yaml
stages:          # Ordine esecuzione: validate → test → build → deploy
  - validate
  - test

cache:           # Ottimizzazione: node_modules cached tra job
  key: ${CI_COMMIT_REF_SLUG}
  paths:
    - node_modules/

rules:           # Conditional execution: solo su MR e branch main
  - if: '$CI_PIPELINE_SOURCE == "merge_request_event"'
```

**Punti chiave**:
- `stages`: definisce l'ordine di esecuzione dei job
- `cache`: riduce tempo build caching `node_modules`
- `rules`: esegue job solo quando necessario (risparmio CI minutes)
- `artifacts`: coverage report integrato direttamente in GitLab UI

### 5.2 Demo Claude Code - Genera Pipeline (5 min)

**PROMPT da usare con Claude Code:**

```
Genera .gitlab-ci.yml per questo progetto TypeScript/Vitest con:
- Lint e typecheck in stage validate
- Test con coverage in stage test
- SAST scanning con Semgrep
- Coverage threshold 80%

Ottimizza per GitLab self-hosted runner.
```

> "Claude Code genera pipeline production-ready in 30 secondi vs 2 ore manuali!"

**Confronta con il template GitLab demo:**

```bash
# Mostra pipeline ottimizzata dall'ambiente GitLab demo
cat /Users/al/buffer/al/foody/gitlab/.gitlab-ci-optimized.yml
```

### 5.3 SAST Security Scanning (5 min)

> "GitLab integra nativamente security scanning. Vediamo come funziona e come si collega alla code review della Fase 4."

**Mostra vulnerabilità intenzionali nel progetto GitLab:**

```bash
# SQL Injection nel checkout
cat /Users/al/buffer/al/foody/gitlab/src/checkout.tsx

# XSS nel login
cat /Users/al/buffer/al/foody/gitlab/src/login.tsx

# Hardcoded secrets
cat /Users/al/buffer/al/foody/gitlab/src/config.ts
```

**Esegui scan SAST con Semgrep:**

```bash
cd /Users/al/buffer/al/foody/gitlab
./scripts/05-security-audit.sh
```

**Output atteso**: Report con 3+ vulnerabilità trovate (SQL injection, XSS, hardcoded secrets)

**Collegamento con Code Review (Fase 4)**:

> "Ricordate la SQL injection che abbiamo trovato nella code review con Claude Code? SAST la trova automaticamente in CI/CD! Questo è il potere dell'automazione: non devi ricordarti di controllare, la pipeline lo fa per te."

### 5.4 Template Intelligenti vs Statici (opzionale, 3 min)

> "La differenza tra template statici (come Yeoman) e Claude Code è che Claude Code capisce il CONTESTO del vostro progetto."

**PROMPT da usare con Claude Code:**

```
Genera un nuovo modulo per gestire notifiche utente che:
- Segue gli stessi pattern di task-manager.ts (versione refactorata)
- Include test completi
- Usa gli stessi tipi e convenzioni del progetto

Il modulo deve supportare:
- Creazione notifica
- Lettura notifiche (con filtri read/unread)
- Mark as read
- Delete
```

> "Notate come il codice generato segue i NOSTRI pattern, non un template generico. Claude Code ha analizzato il progetto e genera codice coerente."

---

## Conclusione e Q&A (5 minuti)

### Riepilogo

| Tecnica | Beneficio |
|---------|-----------|
| TDD | Codice che fa esattamente quello che serve |
| Test di caratterizzazione | Refactoring senza paura |
| Tecnica 5 Perché | Bug risolti alla radice |
| Code Review AI | Security e best practices automatiche |
| GitLab CI/CD | Pipeline automatizzate con SAST |

### Risorse

- Progetto demo testing: questa cartella (`/Users/al/buffer/al/foody/testing`)
- Progetto demo GitLab: `/Users/al/buffer/al/foody/gitlab`
- Documentazione Claude Code: https://docs.anthropic.com/claude-code
- Milestone Testing: https://www.claudecodeninja.com/milestone/11
- Milestone GitLab: https://www.claudecodeninja.com/milestone/12
- Corso completo: claudecodeninja.com

### Domande?

---

## Troubleshooting

### I test non partono

```bash
# Verifica che node_modules esista
ls node_modules

# Se manca, installa
npm install

# Verifica versione Node
node --version  # Deve essere >= 18
```

### Claude Code non risponde come atteso

- Assicurati di essere nella directory corretta del progetto
- Se Claude Code non vede i file, usa path assoluti
- Per risultati più consistenti, includi contesto nel prompt

### Errori TypeScript

```bash
# Verifica errori tipo
npm run typecheck

# Se ci sono errori, possono essere parte della demo
# (il codice legacy ha volutamente type issues)
```
