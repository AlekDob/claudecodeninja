# Demo Testing & Refactoring Workflow con Claude Code

Progetto di esempio per dimostrare l'utilizzo di Claude Code per testing, refactoring e debugging.

## Contenuto

Questo progetto contiene codice preparato per una demo live di 60+ minuti che copre:

1. **TDD (Test-Driven Development)** - Ciclo RED → GREEN → REFACTOR
2. **Debugging Sistematico** - Tecnica dei 5 Perché, root cause analysis
3. **Refactoring Sicuro** - Test di caratterizzazione, modifiche incrementali
4. **Code Review con AI** - Identificazione vulnerabilità e best practices
5. **Automazione** - CI/CD con GitLab e SAST scanning

## Struttura

```
├── src/
│   ├── utils/
│   │   ├── calculator.ts        # Funzioni con BUG INTENZIONALI
│   │   └── calculator.test.ts   # Test da generare durante demo
│   └── features/
│       ├── task-manager.ts      # Codice LEGACY da refactorare
│       └── task-manager.test.ts # Test di caratterizzazione
├── docs/
│   └── DEMO-SCRIPT.md           # Script passo-passo della demo
├── .gitlab-ci.yml               # Pipeline GitLab CI/CD
├── package.json
├── tsconfig.json
└── vitest.config.ts
```

## Setup

```bash
# Installa dipendenze
npm install

# Esegui test
npm test

# Test in watch mode (utile durante la demo)
npm run test:watch

# Test con coverage
npm run test:coverage
```

## Bug Intenzionali

Il file `src/utils/calculator.ts` contiene bug intenzionali per la demo:

| Bug | Funzione | Descrizione |
|-----|----------|-------------|
| #1 | `calculateDiscount` | Accetta prezzi negativi |
| #2 | `calculateDiscount` | Accetta sconti > 100% |
| #3 | `calculateDiscount` | Problemi precisione floating point |
| #4 | `calculateTotal` | Off-by-one error nel loop |
| #5 | `applyBulkDiscount` | Race condition potenziale |

## Codice Legacy

Il file `src/features/task-manager.ts` simula codice legacy con:

- Funzione principale chiamata `x()`
- Parametri con nomi criptici (`a`, `b`, `c`, `d`)
- 200+ righe in una singola funzione
- Magic numbers per le priorità
- Variabili globali
- Nessun TypeScript type

## Eseguire la Demo

1. Leggi lo script completo in `docs/DEMO-SCRIPT.md`
2. Esegui `npm install` prima di iniziare
3. Segui le fasi nell'ordine indicato
4. I prompt per Claude Code sono già pronti da copiare

## Script Demo

Lo script della demo è in `docs/DEMO-SCRIPT.md` e include:

- Setup iniziale
- Prompt esatti da usare con Claude Code
- Output attesi per ogni fase
- Punti di discussione
- Troubleshooting

## Comandi Utili

```bash
npm test              # Esegue tutti i test
npm run test:watch    # Test in modalità watch
npm run test:coverage # Test con report coverage
npm run typecheck     # Verifica tipi TypeScript
```

## Integrazione GitLab CI/CD

Questo progetto include una pipeline GitLab CI/CD pronta all'uso.

### File Pipeline

- `.gitlab-ci.yml` - Pipeline con typecheck, test, SAST scanning

### Collegamento con Demo GitLab

L'ambiente demo GitLab completo (branching strategies, security, CI/CD avanzato) si trova in:

```
../gitlab/
```

Durante la Fase 5 della demo, si fa riferimento a questo ambiente per mostrare:
- Vulnerabilità intenzionali (`checkout.tsx`, `login.tsx`, `config.ts`)
- Script SAST (`scripts/05-security-audit.sh`)
- Pipeline ottimizzata (`.gitlab-ci-optimized.yml`)

## Riferimenti

- [Milestone Testing & Refactoring](https://www.claudecodeninja.com/milestone/11)
- [Milestone GitLab Enterprise](https://www.claudecodeninja.com/milestone/12)
- [Documentazione Claude Code](https://docs.anthropic.com/claude-code)
