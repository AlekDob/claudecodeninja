# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Demo repository for **GitLab Enterprise Integration** training sessions with Claude Code. This is a teaching-focused project demonstrating CI/CD pipelines, branching strategies, code review automation, and security scanning.

**Important**: Source files in `src/` contain **intentional security vulnerabilities** for SAST demo purposes. These should NOT be fixed unless explicitly demonstrating the fix process.

## Commands

```bash
# Build (simulated - demo project)
npm run build

# Lint and typecheck
npm run lint
npm run typecheck

# Tests
npm run test:unit
npm run test:e2e

# GitLab setup verification
source .env && ./scripts/01-setup-gitlab.sh

# SAST security scan
./scripts/05-security-audit.sh
```

## Architecture

### Pipeline Files
- `.gitlab-ci.yml` - Base pipeline with stages: validate → test → build → deploy
- `.gitlab-ci-optimized.yml` - Optimized version demonstrating parallelization, conditional E2E, and improved caching

### Source Structure
- `src/checkout.tsx` - SQL injection vulnerabilities (intentional)
- `src/login.tsx` - XSS vulnerabilities (intentional)
- `src/config.ts` - Hardcoded secrets (intentional)
- `src/featureFlags.ts` - Clean feature flag implementation for trunk-based development
- `src/dashboard/` - Legacy and new dashboard components for merge conflict demos

### Demo Scripts
Scripts in `scripts/` are numbered for sequential execution during training:
1. Setup GitLab connection
2. GitFlow branching demo
3. Trunk-based development demo
4. Merge conflict resolution demo
5. Security audit with Semgrep

## Custom Commands

- `/review` - Enterprise code review checklist focusing on security, performance, standards, and accessibility

## Key Patterns

### Feature Flags (Trunk-Based Development)
```typescript
import { FEATURES, FeatureGate } from './featureFlags';

// Conditional check
if (FEATURES.NEW_DASHBOARD) { ... }

// Component wrapper
<FeatureGate flag="NEW_DASHBOARD" fallback={<Legacy />}>
  <NewFeature />
</FeatureGate>
```

### CI/CD Optimization Points
- Cache key based on `package-lock.json` for dependency-aware invalidation
- Parallel validate stage (lint, typecheck, unit tests, SAST)
- Conditional E2E tests only when frontend files change
- Explicit `needs` for faster deploy after build
