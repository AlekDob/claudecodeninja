Esegui code review sui file modificati con focus enterprise.

## SECURITY (Priorità Alta)

- Verifica input validation su tutti i form
- Check SQL queries per injection (usa prepared statements)
- Cerca XSS: `dangerouslySetInnerHTML`, innerHTML, document.write
- Conferma secrets in .env (MAI hardcoded nel codice)
- Verifica CORS configuration
- Check authentication/authorization su ogni endpoint

## PERFORMANCE

- Identifica re-renders inutili React (useMemo, useCallback mancanti)
- Check database queries: N+1, missing indexes, query non ottimizzate
- Verifica immagini: ottimizzate, lazy loading, dimensioni appropriate
- Bundle size impact: import dinamici per componenti pesanti
- Cache strategy appropriata

## STANDARDS

- Max 20 righe per funzione (split se necessario)
- Max 300 righe per file (creare moduli separati)
- TypeScript strict compliance (no `any`, explicit return types)
- Test coverage >=80% su nuovo codice
- Error handling con try/catch appropriato
- Logging strutturato (no console.log in production)

## ACCESSIBILITÀ

- ARIA labels su elementi interattivi
- Keyboard navigation funzionante (Tab order)
- Color contrast ratio >=4.5:1
- Screen reader compatibility (testa con VoiceOver)
- Focus visible su elementi interattivi

## OUTPUT ATTESO

1. **Issue Trovati**: Lista con severity (CRITICAL/WARNING/INFO)
2. **Suggerimenti Fix**: Code snippets per ogni issue
3. **Score Qualità**: 0-100 basato su check superati
4. **Raccomandazione**: APPROVE / REQUEST_CHANGES / COMMENT

Esempio output:

```
## Code Review Report

### CRITICAL (blocca merge)
- [SECURITY] SQL Injection in checkout.tsx:23
  Fix: Usa prepared statement `db.query('SELECT * FROM orders WHERE id = $1', [orderId])`

### WARNING (da fixare prima del deploy)
- [PERFORMANCE] Re-render inutile in Dashboard.tsx:45
  Fix: Wrap con useMemo

### INFO (suggerimenti)
- [STANDARDS] Funzione troppo lunga in utils.ts:78 (35 righe)
  Suggerimento: Split in helper functions

---
Score: 72/100
Raccomandazione: REQUEST_CHANGES (1 critical issue)
```
