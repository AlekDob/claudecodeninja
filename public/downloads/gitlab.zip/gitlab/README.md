# Demo GitLab Enterprise Integration con Claude Code

Demo pratica per la sessione di corso sulla milestone **GitLab Enterprise Integration**.

## Quick Start

```bash
# 1. Configura variabili ambiente
cp .env.example .env
# Modifica .env con i tuoi valori

# 2. Verifica setup
source .env
./scripts/01-setup-gitlab.sh

# 3. Segui la guida docente
# Apri DEMO-GUIDE.md
```

## Struttura Demo

```
├── DEMO-GUIDE.md          # Guida sessione con timing
├── .gitlab-ci.yml         # Pipeline base
├── .gitlab-ci-optimized.yml  # Pipeline ottimizzata
├── scripts/               # Script eseguibili
├── docs/                  # Documentazione moduli
└── src/                   # Codice esempio
```

## Moduli (2 ore totali)

| Modulo | Durata | Contenuto |
|--------|--------|-----------|
| 1. Setup | 20 min | GitLab self-hosted, token, API |
| 2. CI/CD | 25 min | Pipeline, stages, Claude Code |
| 3. Branching | 25 min | GitFlow vs Trunk-Based |
| 4. Code Review | 20 min | Review automation |
| 5. Security | 20 min | SAST, vulnerabilità |
| 6. Wrap-up | 10 min | Recap, challenge |

## Avvio GitLab con Docker

### Prerequisiti Docker

- Docker e Docker Compose installati
- Almeno 4GB di RAM disponibili per GitLab
- Porte 80 e 2222 libere

### Avvio dell'istanza

```bash
# Avvia GitLab e GitLab Runner
docker compose up -d

# Controlla lo stato dei container
docker compose ps

# Visualizza i log (GitLab impiega 2-5 minuti per avviarsi)
docker compose logs -f gitlab
```

### Primo accesso

1. Attendi che GitLab sia completamente avviato (controlla i log)
2. Recupera la password iniziale di root:
   ```bash
   docker exec gitlab cat /etc/gitlab/initial_root_password
   ```
3. Accedi a http://gitlab.88mph.it con:
   - Username: `root`
   - Password: quella recuperata sopra

### Comandi utili

```bash
# Stop dei container
docker compose stop

# Riavvio
docker compose restart

# Stop e rimozione container (i dati persistono nei volumi)
docker compose down

# Rimozione completa inclusi i volumi (ATTENZIONE: cancella tutti i dati)
docker compose down -v
```

## Configurazione Dominio Personalizzato

Se non disponi di un server DNS, puoi configurare il dominio `gitlab.88mph.it` modificando il file hosts del tuo sistema.

### macOS / Linux

```bash
# Modifica il file hosts (richiede sudo)
sudo nano /etc/hosts

# Aggiungi questa riga alla fine del file:
127.0.0.1   gitlab.88mph.it
```

### Windows

1. Apri il Blocco Note come Amministratore
2. Apri il file `C:\Windows\System32\drivers\etc\hosts`
3. Aggiungi alla fine:
   ```
   127.0.0.1   gitlab.88mph.it
   ```
4. Salva il file

### Verifica

```bash
# Testa che il dominio risolva correttamente
ping gitlab.88mph.it

# Dovrebbe rispondere da 127.0.0.1
```

### Dominio diverso

Se vuoi usare un dominio diverso, modifica:

1. Il file `docker-compose.yml`:
   - `hostname: tuo.dominio.com`
   - `external_url 'http://tuo.dominio.com'`
   - `CI_SERVER_URL=http://tuo.dominio.com`

2. Il file hosts con il nuovo dominio

3. Riavvia i container:
   ```bash
   docker compose down
   docker compose up -d
   ```

## Creazione Repository su GitLab

### Creare un nuovo progetto

1. Accedi a GitLab su http://gitlab.88mph.it
2. Clicca su **New project** (o **+** → **New project/repository**)
3. Seleziona **Create blank project**
4. Compila i campi:
   - **Project name**: nome del progetto (es. `demo-cicd`)
   - **Project URL**: seleziona il namespace (es. `root`)
   - **Visibility Level**: Private, Internal o Public
   - **Initialize repository with a README**: opzionale
5. Clicca **Create project**

### Clonare il repository

```bash
# Via HTTP
git clone http://gitlab.88mph.it/root/demo-cicd.git

# Via SSH (porta 2222)
git clone ssh://git@gitlab.88mph.it:2222/root/demo-cicd.git
```

### Configurare SSH (opzionale)

Per usare SSH, aggiungi la tua chiave pubblica:

1. Vai su **User Settings** → **SSH Keys**
2. Incolla il contenuto di `~/.ssh/id_rsa.pub` (o `id_ed25519.pub`)
3. Clicca **Add key**

Configura SSH per usare la porta 2222:

```bash
# Aggiungi a ~/.ssh/config
Host gitlab.88mph.it
    Port 2222
    User git
```

### Push di un progetto esistente

```bash
cd progetto-esistente
git remote add origin http://gitlab.88mph.it/root/demo-cicd.git
git push -u origin main
```

## Configurazione GitLab Runner

Il runner è già incluso nel `docker-compose.yml`, ma deve essere registrato sul progetto.

### 1. Ottenere il token di registrazione

1. Vai al tuo progetto su GitLab
2. **Settings** → **CI/CD** → **Runners** → **Expand**
3. Nella sezione **Project runners**, clicca **New project runner**
4. Configura:
   - **Tags**: `docker` (o i tag che preferisci)
   - **Run untagged jobs**: ✓ (consigliato per demo)
5. Clicca **Create runner**
6. Copia il **registration token** mostrato

### 2. Registrare il runner

```bash
# Registra il runner nel container
docker exec -it gitlab-runner gitlab-runner register \
  --non-interactive \
  --url "http://gitlab.88mph.it" \
  --token "IL_TUO_TOKEN" \
  --executor "docker" \
  --docker-image "node:18-alpine" \
  --docker-network-mode "host" \
  --description "Docker Runner"
```

Sostituisci `IL_TUO_TOKEN` con il token copiato al passo precedente.

### 3. Verificare la registrazione

```bash
# Controlla lo stato del runner
docker exec gitlab-runner gitlab-runner list

# Verifica i log
docker logs gitlab-runner
```

Su GitLab, il runner dovrebbe apparire con pallino verde in **Settings** → **CI/CD** → **Runners**.

### 4. Testare la pipeline

Crea un file `.gitlab-ci.yml` nel repository:

```yaml
stages:
  - test

test-job:
  stage: test
  script:
    - echo "Pipeline funzionante!"
    - node --version
```

Dopo il push, vai su **Build** → **Pipelines** per vedere l'esecuzione.

### Troubleshooting Runner

```bash
# Riavvia il runner
docker restart gitlab-runner

# Verifica la configurazione
docker exec gitlab-runner cat /etc/gitlab-runner/config.toml

# Re-registra (se necessario, prima rimuovi il runner da GitLab)
docker exec -it gitlab-runner gitlab-runner unregister --all-runners
```

## Prerequisiti

- Docker e Docker Compose (per GitLab self-hosted)
- Claude Code installato (`npm install -g @anthropic-ai/claude-code`)
- Git configurato
- (Opzionale) Semgrep per SAST: `brew install semgrep`

## File con Vulnerabilità (Demo SAST)

I seguenti file contengono vulnerabilità **intenzionali** per demo:

- `src/checkout.tsx` - SQL Injection
- `src/login.tsx` - XSS
- `src/config.ts` - Hardcoded secrets

**NON usare in produzione!**
