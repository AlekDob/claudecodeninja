#!/bin/bash
# 05-security-audit.sh - Demo SAST Security Scanning con Semgrep
# Esegui: ./scripts/05-security-audit.sh

set -e

# Colori
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Directory del progetto
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

clear
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  SAST Security Audit Demo${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo -e "${CYAN}Scansioniamo il codice per vulnerabilità usando Semgrep.${NC}"
echo ""

pause() {
    echo ""
    echo -e "${YELLOW}Premi ENTER per continuare...${NC}"
    read -r
}

# Step 1: Verifica Semgrep
echo -e "${GREEN}[STEP 1] Verifico Semgrep...${NC}"
echo ""

if ! command -v semgrep &> /dev/null; then
    echo -e "${YELLOW}⚠ Semgrep non installato${NC}"
    echo ""
    echo "Installa con:"
    echo "  macOS:  brew install semgrep"
    echo "  pip:    pip install semgrep"
    echo "  docker: docker run returntocorp/semgrep"
    echo ""
    echo "Continuo con output simulato per demo..."
    SEMGREP_AVAILABLE=false
else
    SEMGREP_VERSION=$(semgrep --version 2>/dev/null | head -1)
    echo -e "${GREEN}✓ Semgrep: $SEMGREP_VERSION${NC}"
    SEMGREP_AVAILABLE=true
fi
pause

# Step 2: File con vulnerabilità
echo -e "${GREEN}[STEP 2] File con vulnerabilità intenzionali${NC}"
echo ""
echo -e "${CYAN}Questi file contengono vulnerabilità per demo:${NC}"
echo ""
echo "  src/checkout.tsx  - SQL Injection"
echo "  src/login.tsx     - XSS (dangerouslySetInnerHTML)"
echo "  src/config.ts     - Hardcoded secrets"
echo ""
pause

# Step 3: Mostra vulnerabilità
echo -e "${GREEN}[STEP 3] Anteprima Vulnerabilità${NC}"
echo ""

echo -e "${RED}=== SQL INJECTION (src/checkout.tsx) ===${NC}"
echo ""
grep -n "db.query" "$PROJECT_DIR/src/checkout.tsx" 2>/dev/null || echo "  db.query(\`SELECT * FROM orders WHERE id = '\${orderId}'\`)"
echo ""

echo -e "${RED}=== XSS (src/login.tsx) ===${NC}"
echo ""
grep -n "dangerouslySetInnerHTML" "$PROJECT_DIR/src/login.tsx" 2>/dev/null || echo "  dangerouslySetInnerHTML={{ __html: welcomeMessage }}"
echo ""

echo -e "${RED}=== HARDCODED SECRETS (src/config.ts) ===${NC}"
echo ""
grep -n "sk_live\|password" "$PROJECT_DIR/src/config.ts" 2>/dev/null | head -3 || echo "  STRIPE_SECRET_KEY = 'sk_live_...'"
echo ""
pause

# Step 4: Esegui scan
echo -e "${GREEN}[STEP 4] Eseguo Security Scan...${NC}"
echo ""

if [ "$SEMGREP_AVAILABLE" = true ]; then
    echo -e "${CYAN}Comando: semgrep scan --config=auto src/${NC}"
    echo ""

    cd "$PROJECT_DIR"

    # Esegui scan con output colorato
    semgrep scan \
        --config=auto \
        --config=p/security-audit \
        --config=p/secrets \
        src/ 2>/dev/null || true

else
    # Output simulato per demo senza Semgrep
    echo -e "${CYAN}[OUTPUT SIMULATO - Semgrep non installato]${NC}"
    echo ""
    cat << 'EOF'
┌──────────────────────────────────────────────────────────────┐
│                     Semgrep Scan Results                      │
└──────────────────────────────────────────────────────────────┘

  src/checkout.tsx
  ────────────────
  ❌ CRITICAL: sql-injection
     Line 29: db.query(`SELECT * FROM orders WHERE id = '${orderId}'`)

     User input directly interpolated into SQL query.
     Fix: Use prepared statements with parameterized queries.

     Suggested fix:
     db.query('SELECT * FROM orders WHERE id = $1', [orderId])

  src/login.tsx
  ─────────────
  ❌ HIGH: react-dangerouslysetinnerhtml
     Line 62: dangerouslySetInnerHTML={{ __html: welcomeMessage }}

     User-controlled data in dangerouslySetInnerHTML.
     Fix: Sanitize with DOMPurify or use safe alternatives.

     Suggested fix:
     import DOMPurify from 'dompurify';
     const safeHtml = DOMPurify.sanitize(welcomeMessage);

  ⚠ MEDIUM: password-in-localstorage
     Line 52: localStorage.setItem('savedPassword', password);

     Storing passwords in localStorage is insecure.
     Fix: Use secure session management instead.

  src/config.ts
  ─────────────
  ❌ CRITICAL: hardcoded-secret
     Line 6: STRIPE_SECRET_KEY = 'sk_live_51ABC...'

     Hardcoded API key detected.
     Fix: Move to environment variables.

  ❌ CRITICAL: hardcoded-password
     Line 13: password: 'SuperSecret123!'

     Hardcoded database password.
     Fix: Use environment variables or secrets manager.

  ❌ HIGH: aws-credentials-hardcoded
     Line 19: accessKeyId: 'AKIAIOSFODNN7EXAMPLE'

     AWS credentials in source code.
     Fix: Use AWS credentials file or IAM roles.

┌──────────────────────────────────────────────────────────────┐
│                          Summary                              │
├──────────────────────────────────────────────────────────────┤
│  CRITICAL: 3    HIGH: 2    MEDIUM: 1    LOW: 0               │
│                                                               │
│  Status: FAILED - Critical vulnerabilities found              │
│  Recommendation: Block merge until fixed                      │
└──────────────────────────────────────────────────────────────┘
EOF
fi
pause

# Step 5: Fix con Claude Code
echo -e "${GREEN}[STEP 5] Fix con Claude Code${NC}"
echo ""
echo -e "${CYAN}Prompt per fixare SQL Injection:${NC}"
echo ""
echo "  claude \"Fix la vulnerabilità SQL injection in src/checkout.tsx"
echo "         usando prepared statements\""
echo ""
echo -e "${CYAN}Claude Code modifica:${NC}"
echo ""
cat << 'EOF'
  // PRIMA (vulnerabile)
  const result = await db.query(
    `SELECT * FROM orders WHERE id = '${orderId}'`
  );

  // DOPO (sicuro)
  const result = await db.query(
    'SELECT * FROM orders WHERE id = $1',
    [orderId]
  );
EOF
pause

# Step 6: GitLab CI Integration
echo -e "${GREEN}[STEP 6] Integrazione in GitLab CI${NC}"
echo ""
echo -e "${CYAN}Aggiungi a .gitlab-ci.yml:${NC}"
echo ""
cat << 'EOF'
sast:
  stage: validate
  image: returntocorp/semgrep
  script:
    - semgrep scan --config=auto --json > sast-report.json
  artifacts:
    reports:
      sast: sast-report.json
  allow_failure: false  # Blocca MR se trova critical
  rules:
    - if: '$CI_PIPELINE_SOURCE == "merge_request_event"'
EOF
pause

# Riepilogo
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Riepilogo Security Audit${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo -e "${GREEN}SAST Best Practices:${NC}"
echo ""
echo "  1. Scan automatico su ogni MR"
echo "  2. Block merge su critical issues"
echo "  3. Fix immediato con Claude Code"
echo "  4. Secrets SEMPRE in env vars"
echo "  5. Input validation su boundaries"
echo ""
echo -e "${CYAN}Tools consigliati:${NC}"
echo ""
echo "  - Semgrep: SAST gratuito, ottimo per React/TypeScript"
echo "  - Trivy: Container/dependency scanning"
echo "  - GitLab SAST: Built-in (Premium)"
echo "  - Snyk: SCA + SAST (freemium)"
echo ""
echo -e "${YELLOW}Ricorda: Security è shift-left!${NC}"
echo -e "${YELLOW}Trova problemi in CI, non in production.${NC}"
echo ""
