#!/bin/bash
# 01-setup-gitlab.sh - Setup GitLab Self-Hosted per Demo
# Esegui: ./scripts/01-setup-gitlab.sh

set -e

# Colori per output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  GitLab Self-Hosted Setup Demo${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# 1. Verifica variabili ambiente
echo -e "${YELLOW}[1/5] Verifico variabili ambiente...${NC}"

if [ -z "$GITLAB_URL" ]; then
    echo -e "${RED}❌ GITLAB_URL non configurato${NC}"
    echo "   Esegui: export GITLAB_URL=https://gitlab.tuodominio.com"
    echo "   Oppure configura .env e source .env"
    exit 1
fi

if [ -z "$GITLAB_TOKEN" ]; then
    echo -e "${RED}❌ GITLAB_TOKEN non configurato${NC}"
    echo "   Crea token su: $GITLAB_URL/-/user_settings/personal_access_tokens"
    echo "   Scope richiesti: api, read_repository, write_repository"
    exit 1
fi

echo -e "${GREEN}✓ GITLAB_URL: $GITLAB_URL${NC}"
echo -e "${GREEN}✓ GITLAB_TOKEN: ***${GITLAB_TOKEN: -4}${NC}"
echo ""

# 2. Test connessione API
echo -e "${YELLOW}[2/5] Testo connessione API GitLab...${NC}"

USER_RESPONSE=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
    "$GITLAB_URL/api/v4/user" 2>&1)

if echo "$USER_RESPONSE" | grep -q '"id"'; then
    USERNAME=$(echo "$USER_RESPONSE" | grep -o '"username":"[^"]*"' | cut -d'"' -f4)
    EMAIL=$(echo "$USER_RESPONSE" | grep -o '"email":"[^"]*"' | cut -d'"' -f4)
    echo -e "${GREEN}✓ Connesso come: $USERNAME ($EMAIL)${NC}"
else
    echo -e "${RED}❌ Errore connessione API${NC}"
    echo "   Response: $USER_RESPONSE"
    echo ""
    echo "   Verifica:"
    echo "   1. URL GitLab corretto (includi https://)"
    echo "   2. Token valido e non scaduto"
    echo "   3. Scope token: api, read_repository, write_repository"
    exit 1
fi
echo ""

# 3. Verifica Git configurato
echo -e "${YELLOW}[3/5] Verifico configurazione Git...${NC}"

GIT_USER=$(git config --global user.name 2>/dev/null || echo "")
GIT_EMAIL=$(git config --global user.email 2>/dev/null || echo "")

if [ -z "$GIT_USER" ]; then
    echo -e "${YELLOW}⚠ Git user.name non configurato${NC}"
    echo "   Configurare con: git config --global user.name 'Il Tuo Nome'"
else
    echo -e "${GREEN}✓ Git user.name: $GIT_USER${NC}"
fi

if [ -z "$GIT_EMAIL" ]; then
    echo -e "${YELLOW}⚠ Git user.email non configurato${NC}"
    echo "   Configurare con: git config --global user.email 'tua@email.com'"
else
    echo -e "${GREEN}✓ Git user.email: $GIT_EMAIL${NC}"
fi
echo ""

# 4. Verifica Claude Code
echo -e "${YELLOW}[4/5] Verifico Claude Code...${NC}"

if command -v claude &> /dev/null; then
    CLAUDE_VERSION=$(claude --version 2>/dev/null || echo "installato")
    echo -e "${GREEN}✓ Claude Code: $CLAUDE_VERSION${NC}"
else
    echo -e "${YELLOW}⚠ Claude Code non trovato nel PATH${NC}"
    echo "   Installa con: npm install -g @anthropic-ai/claude-code"
fi
echo ""

# 5. Verifica Semgrep (opzionale)
echo -e "${YELLOW}[5/5] Verifico Semgrep (SAST)...${NC}"

if command -v semgrep &> /dev/null; then
    SEMGREP_VERSION=$(semgrep --version 2>/dev/null | head -1)
    echo -e "${GREEN}✓ Semgrep: $SEMGREP_VERSION${NC}"
else
    echo -e "${YELLOW}⚠ Semgrep non installato (opzionale per SAST demo)${NC}"
    echo "   Installa con: brew install semgrep"
    echo "   Oppure: pip install semgrep"
fi
echo ""

# Riepilogo
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Setup Completato${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo "GitLab URL:  $GITLAB_URL"
echo "Username:    $USERNAME"
echo ""
echo "Prossimi passi:"
echo "1. Crea repository su GitLab per la demo"
echo "2. Esegui ./scripts/02-gitflow-demo.sh per demo GitFlow"
echo "3. Oppure ./scripts/03-trunk-based-demo.sh per Trunk-Based"
echo ""
