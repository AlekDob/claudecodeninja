#!/bin/bash
# 06-sast-report.sh - Scarica e formatta SAST report da GitLab CI
# Uso: ./scripts/06-sast-report.sh [JOB_ID]

set -e

# Carica variabili ambiente
if [ -f .env ]; then
  source .env
fi

# Verifica variabili
if [ -z "$GITLAB_URL" ] || [ -z "$GITLAB_TOKEN" ]; then
  echo "Errore: GITLAB_URL e GITLAB_TOKEN devono essere configurati in .env"
  exit 1
fi

# Project ID (default 1, o passato come secondo argomento)
PROJECT_ID="${2:-1}"

# Se non viene passato JOB_ID, trova l'ultimo job SAST
if [ -z "$1" ]; then
  echo "Cercando ultimo job SAST..."
  JOB_ID=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
    "$GITLAB_URL/api/v4/projects/$PROJECT_ID/jobs?scope=success" | \
    python3 -c "import sys,json; jobs=json.load(sys.stdin); print(next((j['id'] for j in jobs if j['name']=='sast'), ''))")

  if [ -z "$JOB_ID" ]; then
    echo "Errore: Nessun job SAST trovato"
    exit 1
  fi
  echo "Trovato job SAST: $JOB_ID"
else
  JOB_ID="$1"
fi

# Directory output
OUTPUT_DIR="sast-reports"
mkdir -p "$OUTPUT_DIR"

# Scarica artifact
echo "Scaricando sast-report.json dal job $JOB_ID..."
curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  "$GITLAB_URL/api/v4/projects/$PROJECT_ID/jobs/$JOB_ID/artifacts/sast-report.json" \
  -o "$OUTPUT_DIR/sast-report.json"

if [ ! -s "$OUTPUT_DIR/sast-report.json" ]; then
  echo "Errore: Impossibile scaricare il report"
  exit 1
fi

echo "Report scaricato: $OUTPUT_DIR/sast-report.json"

# Genera HTML
echo "Generando report HTML..."
python3 << 'PYTHON_SCRIPT'
import json
from datetime import datetime
from pathlib import Path
import html

# Leggi report
with open("sast-reports/sast-report.json") as f:
    report = json.load(f)

results = report.get("results", [])

def get_code_snippet(file_path, start_line, end_line, context=2):
    """Legge il codice sorgente dal file originale"""
    try:
        path = Path(file_path)
        if not path.exists():
            return "File not found"

        file_lines = path.read_text().splitlines()

        # Aggiungi contesto
        start = max(0, start_line - context - 1)
        end = min(len(file_lines), end_line + context)

        snippet_lines = []
        for i in range(start, end):
            line_num = i + 1
            prefix = ">" if start_line <= line_num <= end_line else " "
            escaped_line = file_lines[i].replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            snippet_lines.append(f"{prefix} {line_num:3d} | {escaped_line}")

        return "\n".join(snippet_lines)
    except Exception as e:
        return f"Error reading file: {e}"

# Conta per severity
severity_count = {"ERROR": 0, "WARNING": 0, "INFO": 0}
for r in results:
    sev = r.get("extra", {}).get("severity", "INFO")
    severity_count[sev] = severity_count.get(sev, 0) + 1

# Genera HTML
html = f"""<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SAST Report - Semgrep</title>
    <style>
        :root {{
            --critical: #dc3545;
            --warning: #ffc107;
            --info: #17a2b8;
            --bg: #1a1a2e;
            --card-bg: #16213e;
            --text: #eee;
            --border: #0f3460;
        }}
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
            padding: 2rem;
        }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        h1 {{
            font-size: 2rem;
            margin-bottom: 0.5rem;
            color: #fff;
        }}
        .subtitle {{
            color: #888;
            margin-bottom: 2rem;
        }}
        .summary {{
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }}
        .stat {{
            background: var(--card-bg);
            border-radius: 8px;
            padding: 1.5rem 2rem;
            text-align: center;
            border: 1px solid var(--border);
            min-width: 150px;
        }}
        .stat-value {{
            font-size: 2.5rem;
            font-weight: bold;
        }}
        .stat-label {{
            color: #888;
            font-size: 0.9rem;
            text-transform: uppercase;
        }}
        .stat.critical .stat-value {{ color: var(--critical); }}
        .stat.warning .stat-value {{ color: var(--warning); }}
        .stat.info .stat-value {{ color: var(--info); }}
        .findings {{ display: flex; flex-direction: column; gap: 1rem; }}
        .finding {{
            background: var(--card-bg);
            border-radius: 8px;
            padding: 1.5rem;
            border-left: 4px solid var(--border);
        }}
        .finding.ERROR {{ border-left-color: var(--critical); }}
        .finding.WARNING {{ border-left-color: var(--warning); }}
        .finding.INFO {{ border-left-color: var(--info); }}
        .finding-header {{
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
            flex-wrap: wrap;
            gap: 0.5rem;
        }}
        .finding-title {{
            font-weight: 600;
            font-size: 1.1rem;
        }}
        .badge {{
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }}
        .badge.ERROR {{ background: var(--critical); color: #fff; }}
        .badge.WARNING {{ background: var(--warning); color: #000; }}
        .badge.INFO {{ background: var(--info); color: #fff; }}
        .finding-location {{
            font-family: 'Monaco', 'Menlo', monospace;
            font-size: 0.85rem;
            color: #888;
            margin-bottom: 0.5rem;
        }}
        .finding-message {{
            color: #ccc;
            margin-bottom: 1rem;
        }}
        .code-block {{
            background: #0d1117;
            border-radius: 6px;
            padding: 1rem;
            overflow-x: auto;
            font-family: 'Monaco', 'Menlo', monospace;
            font-size: 0.85rem;
            border: 1px solid #30363d;
        }}
        .code-block code {{
            color: #c9d1d9;
            white-space: pre;
        }}
        .finding-meta {{
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
            flex-wrap: wrap;
        }}
        .meta-item {{
            font-size: 0.8rem;
            color: #666;
        }}
        .meta-item a {{
            color: var(--info);
            text-decoration: none;
        }}
        .meta-item a:hover {{ text-decoration: underline; }}
        .no-findings {{
            text-align: center;
            padding: 3rem;
            color: #888;
        }}
        .no-findings .icon {{ font-size: 4rem; margin-bottom: 1rem; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>SAST Security Report</h1>
        <p class="subtitle">Generato il {datetime.now().strftime("%Y-%m-%d %H:%M:%S")} con Semgrep</p>

        <div class="summary">
            <div class="stat">
                <div class="stat-value">{len(results)}</div>
                <div class="stat-label">Totale Findings</div>
            </div>
            <div class="stat critical">
                <div class="stat-value">{severity_count.get("ERROR", 0)}</div>
                <div class="stat-label">Critical</div>
            </div>
            <div class="stat warning">
                <div class="stat-value">{severity_count.get("WARNING", 0)}</div>
                <div class="stat-label">Warning</div>
            </div>
            <div class="stat info">
                <div class="stat-value">{severity_count.get("INFO", 0)}</div>
                <div class="stat-label">Info</div>
            </div>
        </div>

        <div class="findings">
"""

if not results:
    html += """
            <div class="no-findings">
                <div class="icon">&#10003;</div>
                <h2>Nessuna vulnerabilita trovata</h2>
                <p>Il codice ha superato tutti i controlli di sicurezza.</p>
            </div>
"""
else:
    for r in results:
        check_id = r.get("check_id", "unknown")
        rule_name = check_id.split(".")[-1] if "." in check_id else check_id
        path = r.get("path", "")
        start_line = r.get("start", {}).get("line", 0)
        end_line = r.get("end", {}).get("line", 0)
        extra = r.get("extra", {})
        severity = extra.get("severity", "INFO")
        message = extra.get("message", "No description")

        # Leggi codice dal file sorgente (Semgrep nasconde il codice senza login)
        code = get_code_snippet(path, start_line, end_line)

        # Link alla documentazione Semgrep
        rule_url = f"https://semgrep.dev/r/{check_id}" if check_id != "unknown" else "#"

        html += f"""
            <div class="finding {severity}">
                <div class="finding-header">
                    <span class="finding-title">{rule_name}</span>
                    <span class="badge {severity}">{severity}</span>
                </div>
                <div class="finding-location">{path}:{start_line}-{end_line}</div>
                <div class="finding-message">{message}</div>
                <div class="code-block"><code>{code}</code></div>
                <div class="finding-meta">
                    <span class="meta-item"><a href="{rule_url}" target="_blank">Documentazione regola</a></span>
                    <span class="meta-item">Rule: {check_id}</span>
                </div>
            </div>
"""

html += """
        </div>
    </div>
</body>
</html>
"""

# Salva HTML
output_path = Path("sast-reports/sast-report.html")
output_path.write_text(html)
print(f"Report HTML generato: {output_path}")
PYTHON_SCRIPT

echo ""
echo "Report generati in $OUTPUT_DIR/:"
ls -la "$OUTPUT_DIR/"
echo ""
echo "Apri il report con: open $OUTPUT_DIR/sast-report.html"
