#!/bin/bash
# 03-trunk-based-demo.sh - Demo Trunk-Based Development
# Esegui: ./scripts/03-trunk-based-demo.sh

set -e

# Colori
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

clear
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Trunk-Based Development Demo${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo -e "${CYAN}Trunk-Based è lo standard 2025 per continuous deployment.${NC}"
echo -e "${CYAN}Regola d'oro: branch vive MAX 1 giorno, merge almeno 1x/giorno.${NC}"
echo ""

pause() {
    echo ""
    echo -e "${YELLOW}Premi ENTER per continuare...${NC}"
    read -r
}

# Step 1: Struttura
echo -e "${GREEN}[STEP 1] Struttura Trunk-Based${NC}"
echo ""
echo "
    main (trunk) ←── tutti merge qui
      │
      ├── short-lived-branch-1 (max 1 giorno)
      ├── short-lived-branch-2 (max 1 giorno)
      └── quick-fix-typo (ore, non giorni)

    NO develop branch
    NO release branch
    NO long-lived feature branch
"
pause

# Step 2: Le 4 Regole
echo -e "${GREEN}[STEP 2] Le 4 Regole Trunk-Based${NC}"
echo ""
echo -e "${CYAN}1. Branch SHORT-LIVED${NC}"
echo "   Max 1 giorno di vita, idealmente ore"
echo ""
echo -e "${CYAN}2. Merge FREQUENTE${NC}"
echo "   Almeno 1 merge su main al giorno per developer"
echo ""
echo -e "${CYAN}3. Feature FLAGS${NC}"
echo "   Nascondi codice incompleto dietro flag"
echo ""
echo -e "${CYAN}4. CI/CD VELOCE${NC}"
echo "   Pipeline < 5 minuti per feedback immediato"
pause

# Step 3: Workflow Veloce
echo -e "${GREEN}[STEP 3] Workflow Veloce${NC}"
echo ""
echo -e "${CYAN}Ciclo tipico (15-30 minuti):${NC}"
echo ""
echo "  # 1. Branch piccolo e focale"
echo "  git checkout main"
echo "  git pull origin main"
echo "  git checkout -b fix-login-button"
echo ""
echo "  # 2. Modifica rapida"
echo "  # ... 10-50 righe di codice ..."
echo ""
echo "  # 3. Test + commit + push"
echo "  npm test"
echo "  git add ."
echo "  git commit -m 'fix: correct login button alignment'"
echo "  git push -u origin fix-login-button"
echo ""
echo "  # 4. MR → Review rapida → Merge"
echo "  # Target: < 1 ora da push a merge"
echo ""
echo "  # 5. Delete branch"
echo "  git checkout main"
echo "  git pull"
echo "  git branch -d fix-login-button"
pause

# Step 4: Feature Flags
echo -e "${GREEN}[STEP 4] Feature Flags in Azione${NC}"
echo ""
echo -e "${CYAN}File: src/featureFlags.ts${NC}"
echo ""
cat << 'EOF'
// featureFlags.ts
export const FEATURES = {
  NEW_DASHBOARD: process.env.NEXT_PUBLIC_FF_DASHBOARD === 'true',
  PAYMENT_V2: process.env.NEXT_PUBLIC_FF_PAYMENT_V2 === 'true',
} as const;

// Uso in componente
import { FEATURES } from '@/lib/featureFlags';

export function Dashboard() {
  if (!FEATURES.NEW_DASHBOARD) {
    return <LegacyDashboard />;  // Versione stabile
  }
  return <NewDashboard />;  // Versione in sviluppo
}
EOF
echo ""
echo -e "${CYAN}Vantaggio: codice incompleto può essere su main${NC}"
echo -e "${CYAN}senza essere visibile agli utenti.${NC}"
pause

# Step 5: Trunk-Based con Claude Code
echo -e "${GREEN}[STEP 5] Claude Code per Trunk-Based${NC}"
echo ""
echo -e "${CYAN}Fix rapido (5 minuti):${NC}"
echo ""
echo "  # 1. Chiedi fix"
echo "  claude 'Correggi typo in homepage hero title'"
echo ""
echo "  # 2. Claude modifica file"
echo "  # ... modifiche automatiche ..."
echo ""
echo "  # 3. Commit e merge immediato"
echo "  git add . && git commit -m 'fix: hero title typo'"
echo "  git push origin main  # Direct push se hai permessi"
echo ""
echo -e "${CYAN}Feature con flag (30 minuti):${NC}"
echo ""
echo "  # 1. Chiedi feature"
echo "  claude 'Aggiungi export CSV a dashboard.'"
echo "         'Nascondi dietro feature flag ADVANCED_EXPORT'"
echo ""
echo "  # 2. Review rapida"
echo "  claude /review"
echo ""
echo "  # 3. Merge su main (feature nascosta)"
echo "  git push origin main"
pause

# Step 6: Confronto GitFlow vs Trunk-Based
echo -e "${GREEN}[STEP 6] GitFlow vs Trunk-Based${NC}"
echo ""
echo "  ┌─────────────────┬──────────────┬────────────────┐"
echo "  │                 │   GitFlow    │  Trunk-Based   │"
echo "  ├─────────────────┼──────────────┼────────────────┤"
echo "  │ Branch lifetime │ Settimane    │ Max 1 giorno   │"
echo "  │ Merge frequency │ Fine feature │ Almeno 1x/day  │"
echo "  │ Deploy frequency│ 2-4 settimane│ 10+ al giorno  │"
echo "  │ Merge conflicts │ Frequenti    │ Rari           │"
echo "  │ Team size ideal │ >20 devs     │ <15 devs       │"
echo "  │ Feature flags   │ Opzionali    │ Essenziali     │"
echo "  └─────────────────┴──────────────┴────────────────┘"
pause

# Riepilogo
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Riepilogo Trunk-Based${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo -e "${GREEN}Pro:${NC}"
echo "  ✓ Merge conflict quasi eliminati"
echo "  ✓ Deploy multipli al giorno"
echo "  ✓ Feedback immediato (<5 min CI)"
echo "  ✓ Codebase sempre deployable"
echo ""
echo -e "${RED}Requisiti:${NC}"
echo "  ✗ CI/CD veloce (<5 minuti)"
echo "  ✗ Test coverage >80%"
echo "  ✗ Feature flags infrastructure"
echo "  ✗ Team disciplinato"
echo ""
echo -e "${CYAN}Usa Trunk-Based quando:${NC}"
echo "  - Continuous deployment (10+ deploy/giorno)"
echo "  - Team <15 persone"
echo "  - Buona test coverage"
echo "  - CI/CD pipeline veloce"
echo ""
