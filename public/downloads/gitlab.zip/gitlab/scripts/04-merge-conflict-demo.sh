#!/bin/bash
# 04-merge-conflict-demo.sh - Demo Merge Conflict Resolution con Claude Code
# Esegui: ./scripts/04-merge-conflict-demo.sh

set -e

# Colori
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

DEMO_DIR="/tmp/gitlab-merge-demo"

clear
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Merge Conflict Demo con Claude Code${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo -e "${CYAN}Simuliamo un merge conflict tipico e lo risolviamo con Claude Code.${NC}"
echo ""

pause() {
    echo ""
    echo -e "${YELLOW}Premi ENTER per continuare...${NC}"
    read -r
}

cleanup() {
    rm -rf "$DEMO_DIR" 2>/dev/null || true
}

# Cleanup all'uscita
trap cleanup EXIT

# Step 1: Setup
echo -e "${GREEN}[STEP 1] Creo repository demo...${NC}"
echo ""

cleanup
mkdir -p "$DEMO_DIR"
cd "$DEMO_DIR"

git init --quiet
git config user.email "demo@example.com"
git config user.name "Demo User"

# Crea file base
cat > Dashboard.tsx << 'EOF'
// Dashboard.tsx - File base
import React from 'react';

interface Props {
  stats: {
    orders: number;
    revenue: number;
  };
}

export function Dashboard({ stats }: Props) {
  return (
    <div className="dashboard">
      <h1>Dashboard</h1>
      <p>Orders: {stats.orders}</p>
      <p>Revenue: €{stats.revenue}</p>
    </div>
  );
}
EOF

git add .
git commit -m "Initial: base dashboard" --quiet

echo -e "${GREEN}✓ Repository creato in $DEMO_DIR${NC}"
pause

# Step 2: Crea branch conflittuali
echo -e "${GREEN}[STEP 2] Creo branch con modifiche conflittuali...${NC}"
echo ""

# Branch feature-stripe
git checkout -b feature-stripe --quiet
cat > Dashboard.tsx << 'EOF'
// Dashboard.tsx - Con integrazione Stripe
import React from 'react';
import { StripeProvider } from './providers/stripe';

interface Props {
  stats: {
    orders: number;
    revenue: number;
  };
}

export function Dashboard({ stats }: Props) {
  return (
    <StripeProvider>
      <div className="dashboard">
        <h1>Dashboard + Stripe</h1>
        <p>Orders: {stats.orders}</p>
        <p>Revenue: €{stats.revenue}</p>
        <StripeCheckout />
      </div>
    </StripeProvider>
  );
}
EOF
git add .
git commit -m "feat: add Stripe integration" --quiet

echo -e "${CYAN}Branch feature-stripe: aggiunge StripeProvider${NC}"

# Torna a main e crea altro branch
git checkout main --quiet
git checkout -b feature-paypal --quiet
cat > Dashboard.tsx << 'EOF'
// Dashboard.tsx - Con integrazione PayPal
import React from 'react';
import { PayPalProvider } from './providers/paypal';

interface Props {
  stats: {
    orders: number;
    revenue: number;
  };
}

export function Dashboard({ stats }: Props) {
  return (
    <PayPalProvider>
      <div className="dashboard">
        <h1>Dashboard + PayPal</h1>
        <p>Orders: {stats.orders}</p>
        <p>Revenue: €{stats.revenue}</p>
        <PayPalButton />
      </div>
    </PayPalProvider>
  );
}
EOF
git add .
git commit -m "feat: add PayPal integration" --quiet

echo -e "${CYAN}Branch feature-paypal: aggiunge PayPalProvider${NC}"
echo ""
echo -e "${GREEN}✓ Due branch con modifiche allo stesso file${NC}"
pause

# Step 3: Merge primo branch
echo -e "${GREEN}[STEP 3] Merge feature-stripe su main...${NC}"
echo ""

git checkout main --quiet
git merge feature-stripe --quiet

echo -e "${GREEN}✓ feature-stripe mergiato senza problemi${NC}"
pause

# Step 4: Tentativo merge secondo branch (CONFLICT!)
echo -e "${GREEN}[STEP 4] Tento merge feature-paypal...${NC}"
echo ""

set +e  # Non esci su errore
MERGE_OUTPUT=$(git merge feature-paypal 2>&1)
MERGE_STATUS=$?
set -e

if [ $MERGE_STATUS -ne 0 ]; then
    echo -e "${RED}❌ MERGE CONFLICT!${NC}"
    echo ""
    echo "$MERGE_OUTPUT"
fi
pause

# Step 5: Mostra conflict
echo -e "${GREEN}[STEP 5] Analizzo conflict...${NC}"
echo ""
echo -e "${CYAN}File Dashboard.tsx con conflict markers:${NC}"
echo ""
cat Dashboard.tsx
pause

# Step 6: Claude Code risolve
echo -e "${GREEN}[STEP 6] Claude Code Risolve il Conflict${NC}"
echo ""
echo -e "${CYAN}Prompt per Claude Code:${NC}"
echo ""
echo "  claude \"Ho merge conflict in Dashboard.tsx tra:"
echo "  - main: implementa Stripe"
echo "  - feature-paypal: implementa PayPal"
echo ""
echo "  Risolvilo mantenendo ENTRAMBI i payment provider"
echo "  con switch runtime basato su prop 'paymentMethod'.\""
echo ""
pause

# Step 7: Mostra risoluzione
echo -e "${GREEN}[STEP 7] Risoluzione Claude Code${NC}"
echo ""
echo -e "${CYAN}Claude Code genererebbe:${NC}"
echo ""

# Risoluzione manuale per demo
cat > Dashboard.tsx << 'EOF'
// Dashboard.tsx - Risoluzione: supporta entrambi i provider
import React from 'react';
import { StripeProvider } from './providers/stripe';
import { PayPalProvider } from './providers/paypal';

interface Props {
  stats: {
    orders: number;
    revenue: number;
  };
  paymentMethod: 'stripe' | 'paypal';
}

export function Dashboard({ stats, paymentMethod }: Props) {
  // Provider wrapper basato su payment method
  const PaymentWrapper = paymentMethod === 'stripe'
    ? StripeProvider
    : PayPalProvider;

  // Checkout component basato su payment method
  const CheckoutComponent = paymentMethod === 'stripe'
    ? () => <StripeCheckout />
    : () => <PayPalButton />;

  return (
    <PaymentWrapper>
      <div className="dashboard">
        <h1>Dashboard</h1>
        <p>Orders: {stats.orders}</p>
        <p>Revenue: €{stats.revenue}</p>
        <CheckoutComponent />
      </div>
    </PaymentWrapper>
  );
}
EOF

cat Dashboard.tsx
pause

# Step 8: Completa merge
echo -e "${GREEN}[STEP 8] Completo merge...${NC}"
echo ""

git add Dashboard.tsx
git commit -m "merge: integrate Stripe and PayPal with runtime switch" --quiet

echo -e "${GREEN}✓ Merge completato con successo!${NC}"
echo ""
git log --oneline -5
pause

# Riepilogo
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Riepilogo${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo -e "${GREEN}Conflict Resolution con Claude Code:${NC}"
echo ""
echo "  1. Git rileva conflict"
echo "  2. Descrivi a Claude le due versioni"
echo "  3. Specifica come vuoi la risoluzione"
echo "  4. Claude genera codice unificato"
echo "  5. Review e commit"
echo ""
echo -e "${CYAN}Tempo risparmiato: 30 min → 2 min${NC}"
echo ""

# Cleanup automatico via trap
echo -e "${YELLOW}Demo directory sarà rimossa automaticamente.${NC}"
echo ""
