#!/bin/bash
# 02-gitflow-demo.sh - Demo GitFlow Workflow
# Esegui: ./scripts/02-gitflow-demo.sh

set -e

# Colori
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

clear
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  GitFlow Workflow Demo${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo -e "${CYAN}GitFlow è lo standard per team enterprise con release scheduled.${NC}"
echo -e "${CYAN}Caratteristiche: branch long-lived, release branches, hotfix.${NC}"
echo ""

# Funzione per pausa interattiva
pause() {
    echo ""
    echo -e "${YELLOW}Premi ENTER per continuare...${NC}"
    read -r
}

# Funzione per mostrare struttura branch
show_branch_structure() {
    echo ""
    echo -e "${BLUE}Struttura GitFlow:${NC}"
    echo "
    main (production)
      │
      ├── develop (integration)
      │     │
      │     ├── feature/user-dashboard
      │     ├── feature/payment-v2
      │     └── feature/export-csv
      │
      └── hotfix/critical-bug (urgente)
    "
}

# Step 1: Mostra struttura
echo -e "${GREEN}[STEP 1] Struttura Branch GitFlow${NC}"
show_branch_structure
pause

# Step 2: Inizializza GitFlow
echo -e "${GREEN}[STEP 2] Inizializzazione Repository${NC}"
echo ""
echo -e "${CYAN}Comandi per inizializzare GitFlow:${NC}"
echo ""
echo "  # Crea branch develop da main"
echo "  git checkout main"
echo "  git checkout -b develop"
echo "  git push -u origin develop"
echo ""
echo "  # Proteggi branch main e develop su GitLab"
echo "  # Settings → Repository → Protected Branches"
pause

# Step 3: Feature Branch
echo -e "${GREEN}[STEP 3] Creare Feature Branch${NC}"
echo ""
echo -e "${CYAN}Workflow per nuova feature:${NC}"
echo ""
echo "  # 1. Crea branch da develop"
echo "  git checkout develop"
echo "  git pull origin develop"
echo "  git checkout -b feature/user-dashboard"
echo ""
echo "  # 2. Sviluppa feature"
echo "  # ... modifiche codice ..."
echo ""
echo "  # 3. Commit"
echo "  git add ."
echo "  git commit -m 'feat: add user dashboard with analytics'"
echo ""
echo "  # 4. Push e crea MR"
echo "  git push -u origin feature/user-dashboard"
pause

# Step 4: Merge Request
echo -e "${GREEN}[STEP 4] Merge Request su GitLab${NC}"
echo ""
echo -e "${CYAN}Creare MR via CLI:${NC}"
echo ""
echo "  # Usando gitlab CLI (glab)"
echo "  glab mr create \\"
echo "    --title 'feat: User Dashboard with Analytics' \\"
echo "    --description 'Implements dashboard with...' \\"
echo "    --target-branch develop"
echo ""
echo -e "${CYAN}Oppure via API:${NC}"
echo ""
echo "  curl --request POST \\"
echo "    --header 'PRIVATE-TOKEN: \$GITLAB_TOKEN' \\"
echo "    --data 'source_branch=feature/user-dashboard' \\"
echo "    --data 'target_branch=develop' \\"
echo "    --data 'title=feat: User Dashboard' \\"
echo "    '\$GITLAB_URL/api/v4/projects/:id/merge_requests'"
pause

# Step 5: Release Branch
echo -e "${GREEN}[STEP 5] Release Branch${NC}"
echo ""
echo -e "${CYAN}Quando develop è pronto per release:${NC}"
echo ""
echo "  # 1. Crea release branch"
echo "  git checkout develop"
echo "  git checkout -b release/1.2.0"
echo ""
echo "  # 2. Bump version, fix last minute bugs"
echo "  # Solo bugfix, NO nuove feature"
echo ""
echo "  # 3. Merge su main E develop"
echo "  git checkout main"
echo "  git merge release/1.2.0"
echo "  git tag v1.2.0"
echo ""
echo "  git checkout develop"
echo "  git merge release/1.2.0"
echo ""
echo "  # 4. Delete release branch"
echo "  git branch -d release/1.2.0"
pause

# Step 6: Hotfix
echo -e "${GREEN}[STEP 6] Hotfix Branch (Urgente)${NC}"
echo ""
echo -e "${CYAN}Bug critico in production:${NC}"
echo ""
echo "  # 1. Crea hotfix da main"
echo "  git checkout main"
echo "  git checkout -b hotfix/critical-security-fix"
echo ""
echo "  # 2. Fix rapido"
echo "  # ... codice fix ..."
echo "  git commit -m 'fix: patch security vulnerability CVE-2024-XXX'"
echo ""
echo "  # 3. Merge su main E develop"
echo "  git checkout main"
echo "  git merge hotfix/critical-security-fix"
echo "  git tag v1.2.1"
echo ""
echo "  git checkout develop"
echo "  git merge hotfix/critical-security-fix"
pause

# Step 7: Claude Code Integration
echo -e "${GREEN}[STEP 7] Claude Code per GitFlow${NC}"
echo ""
echo -e "${CYAN}Usa Claude Code per accelerare GitFlow:${NC}"
echo ""
echo "  # Genera feature completa"
echo "  claude 'Implementa user dashboard con:'"
echo "         '- Stats ordini, revenue, clienti'"
echo "         '- Grafici ultimi 30 giorni'"
echo "         '- Export CSV'"
echo ""
echo "  # Review MR"
echo "  claude /review"
echo ""
echo "  # Risolvi merge conflict"
echo "  claude 'Risolvi conflict tra feature/dashboard e develop'"
pause

# Riepilogo
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Riepilogo GitFlow${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo -e "${GREEN}Pro:${NC}"
echo "  ✓ Chiaro per team grandi (>20 devs)"
echo "  ✓ Release isolate e controllate"
echo "  ✓ Hotfix rapidi senza bloccare develop"
echo ""
echo -e "${RED}Contro:${NC}"
echo "  ✗ Overhead gestione branch"
echo "  ✗ Merge conflict frequenti"
echo "  ✗ Non adatto a continuous deployment"
echo ""
echo -e "${CYAN}Usa GitFlow quando:${NC}"
echo "  - Release scheduled (ogni 2-4 settimane)"
echo "  - Team grandi con feature parallele"
echo "  - Prodotti con versioning esplicito (v1.0, v2.0)"
echo ""
