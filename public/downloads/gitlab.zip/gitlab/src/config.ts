// config.ts - DEMO FILE CON VULNERABILITÀ INTENZIONALI
// ⚠️ NON USARE IN PRODUZIONE - Solo per demo SAST

// ❌ VULNERABILITÀ 1: API Keys hardcoded
// Semgrep detecterà: hardcoded-credentials, secret-in-source
export const STRIPE_SECRET_KEY = 'sk_live_51ABC123DEF456GHI789jklMNOpqrSTUvwxYZ';
export const STRIPE_PUBLISHABLE_KEY = 'pk_live_51ABC123DEF456GHI789jklMNOpqrSTUvwxYZ';

// ❌ VULNERABILITÀ 2: Database credentials hardcoded
export const DATABASE_CONFIG = {
  host: 'prod-db.example.com',
  port: 5432,
  database: 'production_db',
  user: 'admin',
  password: 'SuperSecret123!',  // INSICURO: Password in codice
};

// ❌ VULNERABILITÀ 3: JWT Secret hardcoded
export const JWT_SECRET = 'my-super-secret-jwt-key-that-should-be-in-env';

// ❌ VULNERABILITÀ 4: AWS Credentials
export const AWS_CONFIG = {
  accessKeyId: 'AKIAIOSFODNN7EXAMPLE',
  secretAccessKey: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
  region: 'eu-west-1',
};

// ❌ VULNERABILITÀ 5: OAuth Client Secrets
export const OAUTH_CONFIG = {
  google: {
    clientId: '123456789-abc123def456.apps.googleusercontent.com',
    clientSecret: 'GOCSPX-abc123def456ghi789',
  },
  github: {
    clientId: 'Iv1.abc123def456',
    clientSecret: 'abc123def456ghi789jkl012mno345',
  },
};

// ❌ VULNERABILITÀ 6: Encryption Key hardcoded
export const ENCRYPTION_KEY = 'aes-256-encryption-key-32-chars!';

// ❌ VULNERABILITÀ 7: Private Key in codice
export const PRIVATE_KEY = `-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEA0Z3VS5JJcds3xfn/ygWyF8PbnGy0AHB7MmCs7dxKxFHzNxNr
FAKE_KEY_FOR_DEMO_PURPOSES_ONLY_DO_NOT_USE
-----END RSA PRIVATE KEY-----`;

// ✅ VERSIONE CORRETTA (per confronto):
// export const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY!;
// export const DATABASE_PASSWORD = process.env.DATABASE_PASSWORD!;
// export const JWT_SECRET = process.env.JWT_SECRET!;

// Configurazione pubblica (ok in codice)
export const PUBLIC_CONFIG = {
  appName: 'Demo App',
  apiUrl: 'https://api.example.com',
  version: '1.0.0',
  environment: process.env.NODE_ENV || 'development',
};
