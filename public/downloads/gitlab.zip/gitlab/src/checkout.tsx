// checkout.tsx - DEMO FILE CON VULNERABILITÀ INTENZIONALI
// ⚠️ NON USARE IN PRODUZIONE - Solo per demo SAST

import React, { useState } from 'react';

interface Order {
  id: string;
  total: number;
  items: string[];
}

// Simulazione database connection
const db = {
  query: (sql: string) => {
    console.log('Executing:', sql);
    return Promise.resolve([]);
  }
};

export function Checkout() {
  const [orderId, setOrderId] = useState('');
  const [order, setOrder] = useState<Order | null>(null);

  // ❌ VULNERABILITÀ 1: SQL Injection
  // L'orderId viene interpolato direttamente nella query
  // Un attacker può inserire: ' OR '1'='1
  const fetchOrder = async () => {
    // INSICURO: String interpolation in SQL query
    const result = await db.query(
      `SELECT * FROM orders WHERE id = '${orderId}'`
    );
    // Semgrep detecterà: sql-injection
    setOrder(result[0] as Order);
  };

  // ❌ VULNERABILITÀ 2: SQL Injection con template literal
  const searchOrders = async (searchTerm: string) => {
    // INSICURO: User input diretto in query
    const sql = `SELECT * FROM orders WHERE description LIKE '%${searchTerm}%'`;
    return db.query(sql);
  };

  // ❌ VULNERABILITÀ 3: Command Injection (se eseguito server-side)
  const generateReport = (reportName: string) => {
    // INSICURO: User input in comando shell
    const command = `generate-report --name ${reportName} --output /tmp/`;
    console.log('Would execute:', command);
    // exec(command) - commentato ma pattern rilevabile
  };

  // ✅ VERSIONE CORRETTA (per confronto):
  // const fetchOrderSecure = async () => {
  //   const result = await db.query(
  //     'SELECT * FROM orders WHERE id = $1',
  //     [orderId]  // Prepared statement
  //   );
  //   setOrder(result[0] as Order);
  // };

  return (
    <div className="checkout">
      <h1>Checkout</h1>

      <div className="order-lookup">
        <input
          type="text"
          value={orderId}
          onChange={(e) => setOrderId(e.target.value)}
          placeholder="Enter order ID"
        />
        <button onClick={fetchOrder}>
          Fetch Order
        </button>
      </div>

      {order && (
        <div className="order-details">
          <h2>Order #{order.id}</h2>
          <p>Total: ${order.total}</p>
          <ul>
            {order.items.map((item, i) => (
              <li key={i}>{item}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default Checkout;
