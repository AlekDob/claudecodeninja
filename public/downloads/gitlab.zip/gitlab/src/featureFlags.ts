// featureFlags.ts - Sistema Feature Flags per Trunk-Based Development
// Questo file è SICURO - usato per demo branching strategies

/**
 * Feature Flags per Trunk-Based Development
 *
 * Pattern: Nascondi feature incomplete dietro flag
 * Permette merge frequenti su main senza esporre codice incompleto
 *
 * Uso:
 *   if (FEATURES.NEW_DASHBOARD) {
 *     return <NewDashboard />;
 *   }
 *   return <LegacyDashboard />;
 */

// Feature flags letti da environment variables
export const FEATURES = {
  // Dashboard v2 con analytics avanzati
  NEW_DASHBOARD: process.env.NEXT_PUBLIC_FF_NEW_DASHBOARD === 'true',

  // Nuovo sistema pagamenti con multi-provider
  PAYMENT_V2: process.env.NEXT_PUBLIC_FF_PAYMENT_V2 === 'true',

  // Notifiche real-time con WebSocket
  REALTIME_NOTIFICATIONS: process.env.NEXT_PUBLIC_FF_REALTIME === 'true',

  // Dark mode (in sviluppo)
  DARK_MODE: process.env.NEXT_PUBLIC_FF_DARK_MODE === 'true',

  // Export CSV/Excel avanzato
  ADVANCED_EXPORT: process.env.NEXT_PUBLIC_FF_EXPORT === 'true',
} as const;

// Type per feature flag keys
export type FeatureFlag = keyof typeof FEATURES;

/**
 * Hook per check feature flag
 * @param flag - Nome del feature flag
 * @returns boolean - Se la feature è abilitata
 *
 * @example
 * const isDashboardV2 = useFeatureFlag('NEW_DASHBOARD');
 */
export function isFeatureEnabled(flag: FeatureFlag): boolean {
  return FEATURES[flag] ?? false;
}

/**
 * Componente wrapper per conditional rendering
 *
 * @example
 * <FeatureGate flag="NEW_DASHBOARD">
 *   <NewDashboard />
 * </FeatureGate>
 */
export function FeatureGate({
  flag,
  children,
  fallback = null,
}: {
  flag: FeatureFlag;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}) {
  if (isFeatureEnabled(flag)) {
    return <>{children}</>;
  }
  return <>{fallback}</>;
}

// Per debug: log stato feature flags in development
if (process.env.NODE_ENV === 'development') {
  console.log('Feature Flags:', FEATURES);
}
