// NewDashboard.tsx - Dashboard versione 2 (beta)
// Usato per demo merge conflict con LegacyDashboard.tsx

import React, { useState } from 'react';
import { FEATURES } from '../featureFlags';

interface DashboardStats {
  totalOrders: number;
  revenue: number;
  customers: number;
  // Nuovi campi v2
  conversionRate: number;
  averageOrderValue: number;
  topProducts: string[];
}

interface NewDashboardProps {
  stats: DashboardStats;
}

/**
 * Dashboard v2 - Versione avanzata
 *
 * Nuove caratteristiche:
 * - Analytics avanzati (conversion rate, AOV)
 * - Top products widget
 * - Export CSV (behind feature flag)
 * - Layout responsive migliorato
 *
 * Questa versione sarà in conflitto con LegacyDashboard
 * durante la demo di merge conflict resolution.
 */
export function NewDashboard({ stats }: NewDashboardProps) {
  const [exportFormat, setExportFormat] = useState<'csv' | 'xlsx'>('csv');

  const handleExport = () => {
    console.log(`Exporting as ${exportFormat}...`);
    // Logica export qui
  };

  return (
    <div className="new-dashboard">
      <header className="dashboard-header">
        <h1>Dashboard Analytics</h1>
        {FEATURES.ADVANCED_EXPORT && (
          <div className="export-controls">
            <select
              value={exportFormat}
              onChange={(e) => setExportFormat(e.target.value as 'csv' | 'xlsx')}
            >
              <option value="csv">CSV</option>
              <option value="xlsx">Excel</option>
            </select>
            <button onClick={handleExport}>Export</button>
          </div>
        )}
      </header>

      <div className="stats-grid-v2">
        {/* Stats principali */}
        <div className="stat-card primary">
          <h3>Revenue</h3>
          <p className="stat-value">
            €{stats.revenue.toLocaleString('it-IT')}
          </p>
          <span className="trend positive">+12% vs mese scorso</span>
        </div>

        <div className="stat-card">
          <h3>Ordini</h3>
          <p className="stat-value">{stats.totalOrders}</p>
        </div>

        <div className="stat-card">
          <h3>Clienti</h3>
          <p className="stat-value">{stats.customers}</p>
        </div>

        {/* Nuovi stats v2 */}
        <div className="stat-card">
          <h3>Conversion Rate</h3>
          <p className="stat-value">{stats.conversionRate}%</p>
        </div>

        <div className="stat-card">
          <h3>Valore Medio Ordine</h3>
          <p className="stat-value">
            €{stats.averageOrderValue.toFixed(2)}
          </p>
        </div>
      </div>

      {/* Top Products Widget */}
      <div className="top-products">
        <h2>Top Products</h2>
        <ol>
          {stats.topProducts.map((product, index) => (
            <li key={index}>{product}</li>
          ))}
        </ol>
      </div>

      <style>{`
        .new-dashboard {
          padding: 24px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
        }
        .dashboard-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 24px;
        }
        .dashboard-header h1 {
          color: white;
          margin: 0;
        }
        .export-controls {
          display: flex;
          gap: 8px;
        }
        .stats-grid-v2 {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 16px;
          margin-bottom: 24px;
        }
        .stat-card {
          background: rgba(255,255,255,0.95);
          padding: 20px;
          border-radius: 12px;
          box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .stat-card.primary {
          grid-column: span 2;
          background: white;
        }
        .stat-value {
          font-size: 28px;
          font-weight: bold;
          color: #1a1a2e;
          margin: 8px 0;
        }
        .trend {
          font-size: 14px;
        }
        .trend.positive {
          color: #10b981;
        }
        .top-products {
          background: white;
          padding: 20px;
          border-radius: 12px;
        }
      `}</style>
    </div>
  );
}

export default NewDashboard;
