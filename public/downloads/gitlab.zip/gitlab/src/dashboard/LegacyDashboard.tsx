// LegacyDashboard.tsx - Dashboard versione 1
// Usato per demo merge conflict con NewDashboard.tsx

import React from 'react';

interface DashboardStats {
  totalOrders: number;
  revenue: number;
  customers: number;
}

interface LegacyDashboardProps {
  stats: DashboardStats;
}

/**
 * Dashboard Legacy - Versione originale
 *
 * Caratteristiche:
 * - Layout semplice a griglia
 * - Solo stats base (ordini, revenue, clienti)
 * - Nessun grafico
 * - Nessun export
 *
 * Questa versione sarà in conflitto con NewDashboard
 * durante la demo di merge conflict resolution.
 */
export function LegacyDashboard({ stats }: LegacyDashboardProps) {
  return (
    <div className="legacy-dashboard">
      <h1>Dashboard</h1>

      <div className="stats-grid">
        <div className="stat-card">
          <h3>Ordini Totali</h3>
          <p className="stat-value">{stats.totalOrders}</p>
        </div>

        <div className="stat-card">
          <h3>Revenue</h3>
          <p className="stat-value">
            €{stats.revenue.toLocaleString('it-IT')}
          </p>
        </div>

        <div className="stat-card">
          <h3>Clienti</h3>
          <p className="stat-value">{stats.customers}</p>
        </div>
      </div>

      <style>{`
        .legacy-dashboard {
          padding: 20px;
          background: #f5f5f5;
        }
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 20px;
          margin-top: 20px;
        }
        .stat-card {
          background: white;
          padding: 20px;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .stat-value {
          font-size: 32px;
          font-weight: bold;
          color: #333;
        }
      `}</style>
    </div>
  );
}

export default LegacyDashboard;
