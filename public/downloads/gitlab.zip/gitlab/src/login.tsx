// login.tsx - DEMO FILE CON VULNERABILITÀ INTENZIONALI
// ⚠️ NON USARE IN PRODUZIONE - Solo per demo SAST

import React, { useState } from 'react';

interface User {
  name: string;
  email: string;
  bio: string;
}

export function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [welcomeMessage, setWelcomeMessage] = useState('');
  const [userBio, setUserBio] = useState('');

  const handleLogin = async () => {
    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      });
      const user: User = await response.json();

      // ❌ VULNERABILITÀ 1: XSS con dangerouslySetInnerHTML
      // Il nome utente viene renderizzato senza sanitizzazione
      // Un attacker può registrarsi con nome: <script>alert('XSS')</script>
      setWelcomeMessage(`<h1>Welcome, ${user.name}!</h1>`);

      // ❌ VULNERABILITÀ 2: XSS nella bio utente
      setUserBio(user.bio);

    } catch (err) {
      // ❌ VULNERABILITÀ 3: Error message espone dettagli interni
      setError(`Login failed: ${err}`);
    }
  };

  // ❌ VULNERABILITÀ 4: Password in URL (GET request)
  const resetPassword = () => {
    // INSICURO: Password in query string
    window.location.href = `/reset?email=${email}&temp_password=${password}`;
  };

  // ❌ VULNERABILITÀ 5: localStorage per dati sensibili
  const rememberMe = () => {
    // INSICURO: Password in localStorage
    localStorage.setItem('savedPassword', password);
    localStorage.setItem('savedEmail', email);
  };

  // ✅ VERSIONE CORRETTA (per confronto):
  // import DOMPurify from 'dompurify';
  // const safeWelcome = DOMPurify.sanitize(welcomeMessage);

  return (
    <div className="login-form">
      <h1>Login</h1>

      {error && (
        <div className="error-message">
          {error}
        </div>
      )}

      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Email"
      />

      <input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Password"
      />

      <button onClick={handleLogin}>
        Login
      </button>

      <button onClick={rememberMe}>
        Remember Me
      </button>

      {/* ❌ XSS: dangerouslySetInnerHTML con user input */}
      <div
        dangerouslySetInnerHTML={{ __html: welcomeMessage }}
      />

      {/* ❌ XSS: innerHTML assignment */}
      <div
        ref={(el) => {
          if (el) el.innerHTML = userBio;
        }}
      />
    </div>
  );
}

export default Login;
