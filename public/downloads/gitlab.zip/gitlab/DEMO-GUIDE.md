# Guida Demo GitLab Enterprise Integration

Script dettagliato per la sessione di corso. Segui passo-passo durante la presentazione.

---

## Pre-Demo Checklist

- [ ] GitLab self-hosted accessibile
- [ ] Token GitLab creato con scope `api`, `read_repository`, `write_repository`
- [ ] `.env` configurato con `GITLAB_URL` e `GITLAB_TOKEN`
- [ ] Claude Code attivo: `claude --version`
- [ ] Semgrep installato: `semgrep --version`
- [ ] Repo demo pushato su GitLab

---

## Modulo 1: Setup GitLab Self-Hosted (20 min)

### 1.1 Mostra Configurazione Token (5 min)

Apri `docs/01-SETUP.md` e spiega:

```bash
# Sul tuo GitLab self-hosted:
# Settings → Access Tokens → Personal Access Token
# Scope: api, read_repository, write_repository
```

### 1.2 Esegui Script Setup (5 min)

```bash
# Mostra il file .env.example
cat .env.example

# Copia e configura
cp .env.example .env
# Edita con i valori reali

# Esegui setup
source .env
./scripts/01-setup-gitlab.sh
```

**Output atteso**: Messaggio di conferma con username GitLab.

### 1.3 Demo API GitLab (10 min)

```bash
# Mostra chiamata API manuale
curl --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  "$GITLAB_URL/api/v4/user"

# Lista progetti
curl --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  "$GITLAB_URL/api/v4/projects?per_page=5"
```

**Punto chiave**: GitLab API è la base per automazione CI/CD con Claude Code.

---

## Modulo 2: Pipeline CI/CD (25 min)

### 2.1 Anatomia Pipeline Base (10 min)

Apri `.gitlab-ci.yml` e spiega ogni sezione:

```bash
cat .gitlab-ci.yml
```

**Punti chiave**:
- `stages`: ordine esecuzione
- `variables`: configurazione globale
- `cache`: ottimizzazione build
- `rules`: conditional execution

### 2.2 Demo Claude Code - Genera Pipeline (10 min)

```bash
# Prompt per Claude Code
claude "Genera .gitlab-ci.yml per progetto Next.js 14 con:
- TypeScript strict mode
- Vitest per unit test
- Deploy staging su branch develop
- Deploy production manuale su main
- SAST con Semgrep

Ottimizza per self-hosted runner."
```

**Punto chiave**: Claude Code genera pipeline production-ready in 30 secondi.

### 2.3 Confronto Pipeline Ottimizzata (5 min)

```bash
# Mostra differenze
diff .gitlab-ci.yml .gitlab-ci-optimized.yml

# Oppure side-by-side
cat .gitlab-ci-optimized.yml
```

**Punti chiave ottimizzazione**:
- Parallelizzazione jobs
- Cache per `node_modules`
- Conditional execution
- Artifacts con expiry

---

## Modulo 3: Branching Strategies (25 min)

### 3.1 Demo GitFlow (8 min)

```bash
# Esegui script GitFlow
./scripts/02-gitflow-demo.sh
```

**Spiega mentre esegue**:
- Branch `develop` per integration
- Branch `feature/*` per sviluppo
- Merge Request workflow
- Release branches

### 3.2 Demo Trunk-Based (8 min)

```bash
# Esegui script Trunk-Based
./scripts/03-trunk-based-demo.sh
```

**Punti chiave**:
- Branch short-lived (max 1 giorno)
- Merge frequenti su main
- Feature flags per codice incompleto

### 3.3 Feature Flags (4 min)

```bash
# Mostra implementazione
cat src/featureFlags.ts
```

**Spiega**: Come nascondere feature incomplete in trunk-based.

### 3.4 Demo Merge Conflict con Claude Code (5 min)

```bash
# Crea conflitto
./scripts/04-merge-conflict-demo.sh

# Claude Code risolve
claude "Ho merge conflict in src/dashboard/.
Unisci LegacyDashboard e NewDashboard mantenendo entrambi
con switch basato su feature flag."
```

**Punto chiave**: Claude Code risolve conflict complessi in secondi.

---

## Modulo 4: Code Review Automation (20 min)

### 4.1 Mostra Custom Command (5 min)

```bash
cat .claude/commands/review.md
```

**Spiega**: Checklist personalizzata per review automatiche.

### 4.2 Demo Review con Claude Code (10 min)

```bash
# Simula modifica file
echo "// TODO: fix security" >> src/checkout.tsx

# Esegui review
claude /review
```

**Mostra output**: Claude Code identifica issue e suggerisce fix.

### 4.3 Personalizzazione Checklist (5 min)

```bash
# Modifica live
claude "Aggiungi a .claude/commands/review.md un check per:
- Verifica accessibilità WCAG 2.1
- Performance budget <100KB JS"
```

**Punto chiave**: Review checklist evolve con il progetto.

---

## Modulo 5: Security & Compliance (20 min)

### 5.1 Mostra Vulnerabilità Intenzionali (5 min)

```bash
# SQL Injection
cat src/checkout.tsx
# Cerca: db.query(`SELECT * FROM orders WHERE id = ${orderId}`)

# XSS
cat src/login.tsx
# Cerca: dangerouslySetInnerHTML

# Hardcoded Secrets
cat src/config.ts
# Cerca: STRIPE_KEY = "sk_live_..."
```

**Punto chiave**: Queste vulnerabilità passano inosservate senza scanning.

### 5.2 Demo SAST con Semgrep (10 min)

```bash
# Esegui scan
./scripts/05-security-audit.sh
```

**Output atteso**: Report con 3+ vulnerabilità trovate.

### 5.3 Fix con Claude Code (5 min)

```bash
claude "Fix la vulnerabilità SQL injection in src/checkout.tsx
usando prepared statements"
```

**Mostra diff**: Prima/dopo il fix.

---

## Modulo 6: Wrap-up (10 min)

### 6.1 Recap Ottimizzazioni (5 min)

| Area | Prima | Dopo |
|------|-------|------|
| Pipeline time | 20 min | 4 min |
| Code review | 30 min | 2 min |
| Security scan | Manuale | Automatico |
| Merge conflicts | 30 min | 2 min |

### 6.2 Challenge per Partecipanti (5 min)

"Configura pipeline GitLab production-ready per il tuo progetto:
1. Crea `.gitlab-ci.yml` con Claude Code
2. Aggiungi SAST scanning
3. Configura branch protection
4. Setup automated review"

---

## Troubleshooting

### Token non funziona
```bash
# Verifica permessi token su GitLab
# Settings → Access Tokens → Verifica scope
```

### Semgrep non trova file
```bash
# Assicurati di essere nella directory corretta
cd /path/to/gitlab-demo
semgrep scan --config=auto .
```

### Pipeline fallisce su GitLab
```bash
# Check runner disponibili
curl --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  "$GITLAB_URL/api/v4/runners"
```

---

## Note per il Docente

- Tieni terminale e editor affiancati
- Usa `tmux` o split screen per mostrare più comandi
- Prepara fallback per ogni demo (screenshot output atteso)
- Lascia tempo per domande dopo ogni modulo
