# 05 - Security & Compliance

SAST scanning, secrets management e security best practices.

## SAST (Static Application Security Testing)

Analisi statica del codice per trovare vulnerabilità prima del deploy.

### Cosa Detecta SAST

| Vulnerabilità | Esempio | Severità |
|---------------|---------|----------|
| SQL Injection | `query(\`...${input}\`)` | CRITICAL |
| XSS | `dangerouslySetInnerHTML` | HIGH |
| Hardcoded Secrets | `apiKey = "sk_live_..."` | CRITICAL |
| Path Traversal | `fs.readFile(userPath)` | HIGH |
| Insecure Crypto | `md5(password)` | MEDIUM |

### Setup Semgrep

```bash
# Installazione
brew install semgrep  # macOS
pip install semgrep   # pip

# Scan base
semgrep scan --config=auto .

# Scan con rules specifiche
semgrep scan \
  --config=p/security-audit \
  --config=p/secrets \
  --config=p/react \
  src/
```

### Integrazione GitLab CI

```yaml
sast:
  stage: validate
  image: returntocorp/semgrep
  script:
    - semgrep scan --config=auto --json > sast-report.json
  artifacts:
    reports:
      sast: sast-report.json
  allow_failure: false  # Blocca MR se critical
  rules:
    - if: '$CI_PIPELINE_SOURCE == "merge_request_event"'
```

## Vulnerabilità Demo

### SQL Injection

```typescript
// ❌ VULNERABILE
const result = await db.query(
  `SELECT * FROM orders WHERE id = '${orderId}'`
);

// ✅ SICURO
const result = await db.query(
  'SELECT * FROM orders WHERE id = $1',
  [orderId]
);
```

### XSS

```typescript
// ❌ VULNERABILE
<div dangerouslySetInnerHTML={{ __html: userInput }} />

// ✅ SICURO
import DOMPurify from 'dompurify';
<div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(userInput) }} />

// ✅ MEGLIO
<div>{userInput}</div>  // React escapes by default
```

### Hardcoded Secrets

```typescript
// ❌ VULNERABILE
const STRIPE_KEY = 'sk_live_51ABC...';

// ✅ SICURO
const STRIPE_KEY = process.env.STRIPE_SECRET_KEY;
```

## Secrets Management

### GitLab CI/CD Variables

1. Settings → CI/CD → Variables
2. Add Variable:
   - **Key**: `STRIPE_SECRET_KEY`
   - **Value**: `sk_live_...`
   - **Protected**: ✓ (solo branch protetti)
   - **Masked**: ✓ (nascosto nei log)

### Accesso in Pipeline

```yaml
deploy:
  script:
    - echo "Using key ending in ${STRIPE_SECRET_KEY: -4}"
```

### Pre-commit Hook

```bash
# .husky/pre-commit
#!/bin/sh
npx secretlint "**/*"
```

Blocca commit con secrets hardcoded.

## Fix con Claude Code

### SQL Injection

```bash
claude "Fix SQL injection in src/checkout.tsx usando prepared statements"
```

### XSS

```bash
claude "Rimuovi dangerouslySetInnerHTML in src/login.tsx e usa sanitizzazione con DOMPurify"
```

### Secrets

```bash
claude "Sposta tutti gli hardcoded secrets in src/config.ts a environment variables"
```

## Security Checklist MR

```markdown
## Security Review

- [ ] No hardcoded secrets
- [ ] Input validation su user input
- [ ] Prepared statements per SQL
- [ ] No dangerouslySetInnerHTML con user data
- [ ] CORS configurato correttamente
- [ ] Authentication su tutti gli endpoint
- [ ] Rate limiting su API pubbliche
- [ ] Logging senza dati sensibili
```

## Dependency Security

### npm audit

```yaml
security:deps:
  stage: validate
  script:
    - npm audit --audit-level=high
  allow_failure: false
```

### Renovate/Dependabot

Aggiorna automaticamente dependencies con vulnerabilità note.

## Demo Script

```bash
./scripts/05-security-audit.sh
```

Output:
```
CRITICAL: 3
HIGH: 2
MEDIUM: 1

Status: FAILED - Block merge until fixed
```

## Best Practices

1. **Shift Left**: Trova problemi in CI, non in production
2. **Block on Critical**: Non mergiare con vulnerabilità critiche
3. **Automate**: SAST su ogni MR, non manuale
4. **Fix Fast**: Claude Code per fix immediati
5. **Secrets in Vault**: Mai in codice, mai in git history

## OWASP Top 10 Coverage

| # | Vulnerabilità | Coperto |
|---|---------------|---------|
| 1 | Injection | ✓ Semgrep |
| 2 | Broken Auth | ✓ Review |
| 3 | Sensitive Data | ✓ Secrets scan |
| 4 | XXE | ✓ Semgrep |
| 5 | Broken Access | ✓ Review |
| 6 | Misconfig | ✓ Custom rules |
| 7 | XSS | ✓ Semgrep |
| 8 | Insecure Deser | ✓ Semgrep |
| 9 | Vulnerable Deps | ✓ npm audit |
| 10 | Insufficient Logging | ✓ Review |

## Prossimi Passi

1. [06-OPTIMIZATION.md](./06-OPTIMIZATION.md) - Pipeline Optimization
