# 03 - Branching Strategies

GitFlow vs Trunk-Based Development: quando usare quale.

## GitFlow

### Struttura

```
main (production)
  │
  ├── develop (integration)
  │     │
  │     ├── feature/user-dashboard
  │     ├── feature/payment-v2
  │     └── feature/export-csv
  │
  ├── release/1.2.0
  │
  └── hotfix/critical-bug
```

### Workflow

1. **Feature Branch**
   ```bash
   git checkout develop
   git checkout -b feature/new-feature
   # ... sviluppo ...
   git push origin feature/new-feature
   # Crea MR verso develop
   ```

2. **Release Branch**
   ```bash
   git checkout develop
   git checkout -b release/1.2.0
   # Bump version, final fixes
   git checkout main && git merge release/1.2.0
   git tag v1.2.0
   git checkout develop && git merge release/1.2.0
   ```

3. **Hotfix**
   ```bash
   git checkout main
   git checkout -b hotfix/security-patch
   # Fix urgente
   git checkout main && git merge hotfix/security-patch
   git checkout develop && git merge hotfix/security-patch
   ```

### Quando Usare GitFlow

✅ Team grandi (>20 developers)
✅ Release scheduled (ogni 2-4 settimane)
✅ Prodotti con versioning esplicito (v1.0, v2.0)
✅ Necessità di multiple release parallele

### Pro e Contro

| Pro | Contro |
|-----|--------|
| Struttura chiara | Overhead branches |
| Release controllate | Merge conflict frequenti |
| Hotfix isolati | Lento per CD |

## Trunk-Based Development

### Struttura

```
main (trunk)
  │
  ├── short-branch-1 (max 1 giorno)
  ├── short-branch-2 (max 1 giorno)
  └── quick-fix (ore)
```

### Le 4 Regole

1. **Branch SHORT-LIVED**: Max 1 giorno
2. **Merge FREQUENTE**: Almeno 1x/giorno
3. **Feature FLAGS**: Nascondi codice incompleto
4. **CI/CD VELOCE**: Pipeline < 5 minuti

### Workflow

```bash
# Ciclo tipico: 15-30 minuti
git checkout main && git pull
git checkout -b fix-button-alignment

# Modifica rapida (10-50 righe)
# ...

npm test
git add . && git commit -m "fix: button alignment"
git push origin fix-button-alignment

# MR → Review rapida → Merge → Delete branch
```

### Feature Flags

```typescript
// featureFlags.ts
export const FEATURES = {
  NEW_DASHBOARD: process.env.NEXT_PUBLIC_FF_DASHBOARD === 'true',
};

// Uso
if (FEATURES.NEW_DASHBOARD) {
  return <NewDashboard />;
}
return <LegacyDashboard />;
```

Codice incompleto può essere su main senza essere visibile.

### Quando Usare Trunk-Based

✅ Team piccoli (<15 developers)
✅ Continuous deployment (10+ deploy/giorno)
✅ Test coverage >80%
✅ CI/CD veloce (<5 min)

### Pro e Contro

| Pro | Contro |
|-----|--------|
| Merge conflict rari | Richiede disciplina |
| Deploy multipli/giorno | Richiede feature flags |
| Feedback immediato | CI deve essere veloce |

## Confronto

| Aspetto | GitFlow | Trunk-Based |
|---------|---------|-------------|
| Branch lifetime | Settimane | Max 1 giorno |
| Merge frequency | Fine feature | 1x/giorno |
| Deploy frequency | 2-4 settimane | 10+/giorno |
| Merge conflicts | Frequenti | Rari |
| Feature flags | Opzionali | Essenziali |

## Merge Conflict con Claude Code

Quando hai conflict:

```bash
claude "Ho merge conflict in Dashboard.tsx tra:
- main: implementa Stripe
- feature-paypal: implementa PayPal

Risolvilo mantenendo ENTRAMBI i provider
con switch runtime basato su prop."
```

Claude Code analizza entrambe le versioni e genera soluzione unificata.

**Tempo**: 30 min → 2 min

## Demo Script

```bash
# GitFlow demo
./scripts/02-gitflow-demo.sh

# Trunk-Based demo
./scripts/03-trunk-based-demo.sh

# Merge conflict demo
./scripts/04-merge-conflict-demo.sh
```

## Prossimi Passi

1. [04-CODE-REVIEW.md](./04-CODE-REVIEW.md) - Review Automation
2. [05-SECURITY.md](./05-SECURITY.md) - SAST e Secrets
