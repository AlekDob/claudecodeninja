# 01 - Setup GitLab Self-Hosted

Configurazione ambiente per integrazione Claude Code con GitLab Enterprise.

## Prerequisiti

- GitLab self-hosted (versione 15.0+)
- Accesso admin o permessi per creare token
- Node.js 18+ (per Claude Code)
- Git 2.30+

## 1. Creazione Token GitLab

### Via Web UI

1. Accedi a GitLab self-hosted
2. Vai su **Settings → Access Tokens**
3. Crea nuovo token con scope:
   - `api` (full access)
   - `read_repository`
   - `write_repository`
4. Salva il token (visibile solo una volta!)

### Verifica Token

```bash
# Test connessione
curl --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  "$GITLAB_URL/api/v4/user"

# Output atteso
{
  "id": 1,
  "username": "tuousername",
  "email": "tua@email.com",
  ...
}
```

## 2. Configurazione Ambiente

### File .env

```bash
# Copia template
cp .env.example .env

# Modifica con i tuoi valori
GITLAB_URL=https://gitlab.tuodominio.com
GITLAB_TOKEN=glpat-xxxxxxxxxxxxxxxxxxxx
```

### Configurazione Git

```bash
# Imposta credenziali globali
git config --global user.name "Il Tuo Nome"
git config --global user.email "tua@email.com"

# Credential helper per token
git config --global credential.helper store
```

## 3. Installazione Claude Code

```bash
# Via npm
npm install -g @anthropic-ai/claude-code

# Verifica installazione
claude --version

# Prima configurazione
claude
# Segui wizard autenticazione Anthropic
```

## 4. Script Setup Automatico

```bash
# Esegui script di verifica
source .env
./scripts/01-setup-gitlab.sh
```

Output atteso:
```
✓ GITLAB_URL: https://gitlab.tuodominio.com
✓ GITLAB_TOKEN: ***xxxx
✓ Connesso come: tuousername
✓ Git configurato
✓ Claude Code installato
```

## 5. Installazione Semgrep (Opzionale)

Per demo SAST security scanning:

```bash
# macOS
brew install semgrep

# pip
pip install semgrep

# Verifica
semgrep --version
```

## Troubleshooting

### Token non valido

```
401 Unauthorized
```

- Verifica token non scaduto
- Controlla scope (api, read_repository, write_repository)
- Assicurati URL corretto (con https://)

### SSL Certificate Error

```
SSL certificate problem: self-signed certificate
```

Per ambienti development:
```bash
git config --global http.sslVerify false
# ⚠️ Solo per test, non in production!
```

### GitLab non raggiungibile

```
Could not resolve host
```

- Verifica VPN/network access
- Controlla DNS resolution
- Prova con IP diretto

## Prossimi Passi

1. [02-GITLAB-CI.md](./02-GITLAB-CI.md) - Configurazione Pipeline
2. [03-BRANCHING.md](./03-BRANCHING.md) - Strategie di Branching
