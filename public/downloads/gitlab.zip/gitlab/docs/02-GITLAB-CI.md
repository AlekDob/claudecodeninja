# 02 - GitLab CI/CD Pipeline

Anatomia e configurazione di pipeline production-ready con Claude Code.

## Struttura .gitlab-ci.yml

```yaml
stages:
  - validate    # lint, typecheck, sast
  - test        # unit, e2e
  - build       # compile, bundle
  - deploy      # staging, production
```

## Stages Spiegati

### 1. Validate

Prima linea di difesa: controlli rapidi che falliscono subito.

```yaml
lint:
  stage: validate
  script:
    - npm run lint
    - npm run typecheck
  rules:
    - if: '$CI_PIPELINE_SOURCE == "merge_request_event"'
```

**Perché**: Fallisce in <1 minuto se ci sono errori syntax/type.

### 2. Test

Test automatizzati per garantire correttezza.

```yaml
test:unit:
  stage: test
  script:
    - npm run test:unit -- --coverage
  coverage: '/All files[^|]*\|[^|]*\s+([\d\.]+)/'
  artifacts:
    reports:
      coverage_report:
        coverage_format: cobertura
        path: coverage/cobertura-coverage.xml
```

**Coverage Report**: GitLab mostra percentuale coverage direttamente in MR.

### 3. Build

Compilazione e bundling per deploy.

```yaml
build:
  stage: build
  script:
    - npm run build
  artifacts:
    paths:
      - dist/
    expire_in: 1 week
```

**Artifacts**: Build salvata e riutilizzata in deploy stage.

### 4. Deploy

Deploy su ambienti target.

```yaml
deploy:staging:
  stage: deploy
  script:
    - curl -X POST $WEBHOOK_STAGING
  environment:
    name: staging
    url: https://staging.example.com
  only:
    - develop

deploy:production:
  stage: deploy
  when: manual  # Richiede click manuale
  only:
    - main
```

**Manual Deploy**: Production richiede approvazione esplicita.

## Variabili CI/CD

### Configurazione su GitLab

Settings → CI/CD → Variables:

| Variable | Value | Protected | Masked |
|----------|-------|-----------|--------|
| WEBHOOK_STAGING | https://... | ✓ | ✓ |
| WEBHOOK_PRODUCTION | https://... | ✓ | ✓ |
| STRIPE_SECRET_KEY | sk_live_... | ✓ | ✓ |

### Uso in Pipeline

```yaml
script:
  - echo "Deploying with token ending in ${STRIPE_SECRET_KEY: -4}"
```

## Generare Pipeline con Claude Code

### Prompt Base

```bash
claude "Genera .gitlab-ci.yml per progetto Next.js con:
- TypeScript strict
- Vitest per test
- Deploy Vercel
- SAST scanning"
```

### Prompt Avanzato

```bash
claude "Genera .gitlab-ci.yml ottimizzato per:
- Self-hosted runner con Docker executor
- Cache npm su shared volume
- Parallel matrix per test multi-browser
- Deploy staging automatico, production manuale
- Security scan con Semgrep
- Notifica Slack su failure"
```

## Best Practices

### 1. Cache Dependencies

```yaml
cache:
  key:
    files:
      - package-lock.json
  paths:
    - node_modules/
```

Risparmio: ~2 minuti per job.

### 2. Conditional Execution

```yaml
test:e2e:
  rules:
    - changes:
        - src/pages/**/*
        - src/components/**/*
```

Risparmio: 60% CI minutes (E2E solo se tocchi frontend).

### 3. Parallel Jobs

```yaml
test:
  parallel:
    matrix:
      - BROWSER: [chrome, firefox, safari]
```

3 browser in parallelo invece che sequenziali.

### 4. Artifacts Expiry

```yaml
artifacts:
  expire_in: 3 days  # Non 1 week!
```

Risparmio storage GitLab.

## Confronto Pipeline

Vedi file `.gitlab-ci-optimized.yml` per versione ottimizzata.

| Metrica | Base | Ottimizzata |
|---------|------|-------------|
| Tempo totale | ~20 min | ~5 min |
| CI minutes/mese | 1000 | 300 |
| Cache hit rate | 60% | 95% |

## Prossimi Passi

1. [03-BRANCHING.md](./03-BRANCHING.md) - GitFlow vs Trunk-Based
2. [04-CODE-REVIEW.md](./04-CODE-REVIEW.md) - Review Automation
