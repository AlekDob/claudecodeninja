# 06 - Pipeline Optimization

Ottimizzare pipeline CI/CD per velocità, costi e developer experience.

## Il Problema

Pipeline lenta = developer frustrati:

```
Developer pusha → Pipeline 20 min → Context switch →
Pipeline fail → Ri-contestualizzare (10 min) →
Fix → Re-push → Ripeti...
```

**Goal**: Pipeline < 5 minuti per feedback immediato.

## Ottimizzazioni Chiave

### 1. Parallelizzazione

**Prima (seriale)**: 15 minuti

```yaml
stages:
  - lint     # 3 min
  - test     # 8 min
  - build    # 4 min
```

**Dopo (parallelo)**: 8 minuti

```yaml
stages:
  - validate  # lint + test in parallelo

lint:
  stage: validate

test:
  stage: validate
```

**Risparmio**: 47%

### 2. Cache Intelligente

**Prima**: Reinstalla node_modules ogni volta

```yaml
cache:
  paths:
    - node_modules/
```

**Dopo**: Cache invalidata solo quando dependencies cambiano

```yaml
cache:
  key:
    files:
      - package-lock.json
  paths:
    - node_modules/
    - .next/cache/
```

**Risparmio**: ~2 min per job

### 3. Conditional Execution

**Prima**: E2E test sempre

```yaml
test:e2e:
  script:
    - npm run test:e2e
```

**Dopo**: E2E solo se cambi frontend

```yaml
test:e2e:
  rules:
    - changes:
        - src/pages/**/*
        - src/components/**/*
```

**Risparmio**: 60% CI minutes

### 4. Docker Layer Caching

**Prima**: Rebuild tutto

```dockerfile
FROM node:20
COPY . .
RUN npm ci
RUN npm run build
```

**Dopo**: Layer cache ottimizzato

```dockerfile
FROM node:20

# Layer 1: Dependencies (cambia raramente)
COPY package*.json ./
RUN npm ci

# Layer 2: Source (cambia spesso)
COPY . .
RUN npm run build
```

**Risparmio**: 70% tempo build

### 5. Artifacts Expiry

**Prima**: Artifacts per sempre

```yaml
artifacts:
  paths:
    - dist/
```

**Dopo**: Expiry ragionevole

```yaml
artifacts:
  paths:
    - dist/
  expire_in: 3 days
```

**Risparmio**: Storage GitLab

### 6. Needs Espliciti

**Prima**: Aspetta tutto

```yaml
deploy:
  stage: deploy
```

**Dopo**: Parte appena possibile

```yaml
deploy:
  stage: deploy
  needs:
    - build
```

## Confronto Completo

| Ottimizzazione | Prima | Dopo | Risparmio |
|----------------|-------|------|-----------|
| Parallelizzazione | 15 min | 8 min | 47% |
| Cache npm | 3 min/job | 30 sec/job | 83% |
| Conditional E2E | Sempre | Solo frontend | 60% |
| Docker cache | 5 min | 1.5 min | 70% |
| Artifacts | 1 week | 3 days | Storage |
| Needs | Sequenziale | Parallelo | Variable |

**Totale Pipeline**: 20 min → 5 min (**-75%**)

## Claude Code per Ottimizzazione

### Analisi Pipeline

```bash
claude "Analizza .gitlab-ci.yml e suggerisci ottimizzazioni per:
- Ridurre execution time
- Minimizzare CI minutes cost
- Mantenere code coverage
- Improve caching"
```

### Genera Pipeline Ottimizzata

```bash
claude "Riscrivi .gitlab-ci.yml con:
- Parallel jobs dove possibile
- Cache basata su lockfile
- Conditional execution per E2E
- Needs espliciti per deploy"
```

## Metriche da Monitorare

### GitLab CI/CD Analytics

Settings → CI/CD → Pipelines → Analytics

- **Pipeline duration**: Tempo medio
- **Success rate**: % pipeline verdi
- **Queue time**: Tempo attesa runner

### Goals

| Metrica | Target |
|---------|--------|
| Pipeline duration | < 5 min |
| Success rate | > 95% |
| Queue time | < 30 sec |

## Cost Optimization

### Calcolo CI Minutes

GitLab.com charging:
- Linux: 1x
- macOS: 6x
- Windows: 2x

### Strategie Risparmio

1. **Cache aggressivo**: Evita reinstall
2. **Conditional jobs**: Solo quando serve
3. **Self-hosted runners**: Per volumi alti
4. **Artifacts expiry**: Riduce storage

### Esempio Calcolo

**Prima**:
- 50 MR/giorno × 20 min = 1000 min/giorno
- 1000 × 22 giorni = 22.000 min/mese

**Dopo ottimizzazione**:
- 50 MR/giorno × 5 min = 250 min/giorno
- 250 × 22 giorni = 5.500 min/mese

**Risparmio**: 16.500 min/mese = **€500+/mese** su GitLab.com

## Pipeline File Ottimizzato

Vedi `.gitlab-ci-optimized.yml` per esempio completo.

## Checklist Ottimizzazione

- [ ] Jobs indipendenti in parallelo
- [ ] Cache key basata su lockfile
- [ ] Conditional execution per test pesanti
- [ ] Docker layer caching
- [ ] Artifacts con expiry
- [ ] Needs espliciti
- [ ] Self-hosted runner se >10K min/mese

## Troubleshooting

### Pipeline ancora lenta

1. Check runner availability (queue time)
2. Profila singoli jobs
3. Verifica cache hit rate
4. Considera self-hosted runner

### Cache miss frequenti

1. Verifica key configuration
2. Check file changes detection
3. Usa `policy: pull-push`

### Artifacts troppo grandi

1. Riduci paths
2. Aggiungi exclude patterns
3. Comprimi prima di upload

## Riepilogo

Pipeline ottimizzata = Developer felici = Più produttività

```
20 min pipeline → Context switch → Frustrazione → -50% produttività
5 min pipeline → Feedback immediato → Flow state → +100% produttività
```

**Investimento**: 2 ore ottimizzazione
**ROI**: Migliaia di ore risparmiate all'anno
