# 04 - Code Review Automation

Automatizzare code review con Claude Code per risparmiare tempo e migliorare qualità.

## Il Problema

Scenario tipico team enterprise:
- 50 Merge Request al giorno
- Ogni review: 15-30 minuti
- **Totale: 12-25 ore/giorno di review**

Costo annuale: €150K-300K in tempo developer!

## Soluzione: AI-Driven Review

Claude Code può eseguire review automatiche su ogni MR:

### Setup Custom Command

File `.claude/commands/review.md`:

```markdown
Esegui code review sui file modificati con focus:

SECURITY:
- Input validation
- SQL injection
- XSS vulnerabilities
- Hardcoded secrets

PERFORMANCE:
- Re-renders inutili
- N+1 queries
- Bundle size

STANDARDS:
- Max 20 righe/funzione
- Max 300 righe/file
- TypeScript strict
- Test coverage >=80%

OUTPUT:
1. Issue list (CRITICAL/WARNING/INFO)
2. Suggested fixes con code snippets
3. Quality score 0-100
4. Recommendation: APPROVE / REQUEST_CHANGES
```

### Uso

```bash
# In qualsiasi momento durante sviluppo
claude /review

# Claude analizza tutti i file modificati
# e genera report dettagliato
```

## Cosa Controlla Claude Code

### 1. Security Issues

```typescript
// ❌ Trova questo
const result = await db.query(`SELECT * FROM users WHERE id = ${userId}`);

// ✅ Suggerisce questo
const result = await db.query('SELECT * FROM users WHERE id = $1', [userId]);
```

### 2. Performance Problems

```typescript
// ❌ Trova questo
function Dashboard({ data }) {
  const processed = expensiveComputation(data); // Ricalcola ogni render
  return <Chart data={processed} />;
}

// ✅ Suggerisce questo
function Dashboard({ data }) {
  const processed = useMemo(() => expensiveComputation(data), [data]);
  return <Chart data={processed} />;
}
```

### 3. Standards Violations

```typescript
// ❌ Trova funzione troppo lunga (>20 righe)
function handleSubmit() {
  // 50 righe di codice...
}

// ✅ Suggerisce split
function validateForm() { ... }
function submitToAPI() { ... }
function handleResponse() { ... }

function handleSubmit() {
  if (!validateForm()) return;
  const response = await submitToAPI();
  handleResponse(response);
}
```

## Integrazione GitLab CI

### Pipeline Auto-Review

```yaml
# .gitlab-ci.yml
code-review:
  stage: validate
  image: node:20-alpine
  before_script:
    - npm install -g @anthropic-ai/claude-code
  script:
    - claude /review > review-report.md
    - cat review-report.md
  artifacts:
    paths:
      - review-report.md
  rules:
    - if: '$CI_PIPELINE_SOURCE == "merge_request_event"'
```

### Auto-Comment su MR

```yaml
code-review-comment:
  stage: validate
  script:
    - claude /review > report.md
    - |
      curl --request POST \
        --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
        --data-urlencode "body=$(cat report.md)" \
        "$CI_API_V4_URL/projects/$CI_PROJECT_ID/merge_requests/$CI_MERGE_REQUEST_IID/notes"
  rules:
    - if: '$CI_PIPELINE_SOURCE == "merge_request_event"'
```

## Personalizzazione Checklist

### Per Progetto React

```markdown
REACT SPECIFIC:
- Verifica hooks rules (no conditional hooks)
- Check prop drilling (>3 livelli = useContext)
- Verifica key props in lists
- Check useEffect dependencies
```

### Per Progetto API

```markdown
API SPECIFIC:
- Verifica rate limiting
- Check authentication middleware
- Valida input con Zod/Yup
- Verifica error responses (no stack traces)
```

### Per Progetto Database

```markdown
DATABASE SPECIFIC:
- Check migrations reversibili
- Verifica indexes su foreign keys
- No raw SQL in application code
- Transaction boundaries corretti
```

## Metriche

### Prima di AI Review

| Metrica | Valore |
|---------|--------|
| Tempo medio review | 25 min |
| Review/giorno/dev | 4 |
| Bug sfuggiti | 15/mese |

### Dopo AI Review

| Metrica | Valore |
|---------|--------|
| Tempo medio review | 5 min |
| Review/giorno/dev | 15 |
| Bug sfuggiti | 3/mese |

**ROI**: 80% riduzione tempo, 80% riduzione bug.

## Best Practices

1. **AI + Human**: AI per check meccanici, human per architettura
2. **Customize Checklist**: Adatta a standard del progetto
3. **Iterate**: Aggiungi check per pattern ricorrenti
4. **Trust but Verify**: Review AI suggestions prima di applicare

## Demo

```bash
# Modifica un file
echo "// TODO: fix" >> src/checkout.tsx

# Esegui review
claude /review
```

## Prossimi Passi

1. [05-SECURITY.md](./05-SECURITY.md) - SAST e Secrets
2. [06-OPTIMIZATION.md](./06-OPTIMIZATION.md) - Pipeline Optimization
